"""
High-Level Control Library for Franka Robots
"""
from __future__ import annotations
import builtins
import collections.abc
import numpy
import numpy.typing
import typing
__all__: list[str] = ['Affine', 'BaseCartesianPoseMotion', 'BaseCartesianVelocityMotion', 'BaseJointPositionMotion', 'BaseJointVelocityMotion', 'BaseTorqueMotion', 'BoolFuture', 'CartesianImpedanceBase', 'CartesianImpedanceGains', 'CartesianImpedanceMotion', 'CartesianImpedanceMotionParams', 'CartesianImpedanceParams', 'CartesianImpedanceTrackingMotion', 'CartesianMotion', 'CartesianPose', 'CartesianPoseReaction', 'CartesianReference', 'CartesianState', 'CartesianStopMotion', 'CartesianVelocities', 'CartesianVelocityMotion', 'CartesianVelocityReaction', 'CartesianVelocityStopMotion', 'CartesianVelocityWaypoint', 'CartesianVelocityWaypointMotion', 'CartesianWaypoint', 'CartesianWaypointMotion', 'CommandException', 'Condition', 'ControlException', 'ControlSignalType', 'ControllerMode', 'DoubleDynamicsLimit', 'Duration', 'ElbowState', 'Errors', 'Exception', 'FlipDirection', 'Frame', 'FrictionCompensationParams', 'Gripper', 'GripperException', 'GripperState', 'ImpedanceMotion', 'IncompatibleVersionException', 'InvalidMotionTypeException', 'InvalidOperationException', 'JointImpedanceBase', 'JointImpedanceGains', 'JointImpedanceMotion', 'JointImpedanceParams', 'JointImpedanceTrackingMotion', 'JointMotion', 'JointPositionReaction', 'JointPositions', 'JointReference', 'JointState', 'JointStopMotion', 'JointVelocities', 'JointVelocityMotion', 'JointVelocityReaction', 'JointVelocityStopMotion', 'JointVelocityWaypoint', 'JointVelocityWaypointMotion', 'JointWaypoint', 'JointWaypointMotion', 'ManipulabilityTask', 'Measure', 'Model', 'ModelException', 'MotionReuseException', 'NetworkException', 'NullspaceGains', 'PostureTask', 'ProtocolException', 'ReactionRecursionException', 'RealtimeConfig', 'RealtimeException', 'ReferenceType', 'RelativeDynamicsFactor', 'RobotMode', 'RobotPose', 'RobotState', 'RobotVelocity', 'SimpleTorqueMotion', 'SimpleTorqueParams', 'TorqueReaction', 'TorqueSafetyParams', 'TorqueSignalTimeoutException', 'TorqueStopMotion', 'TorqueStopParams', 'Torques', 'Twist', 'TwistAcceleration', 'VectorDynamicsLimit']
class Affine:
    """
    A rigid 3D transformation consisting of a translation and a rotation. Used to represent poses and coordinate frame transformations.
    """
    def __getstate__(self) -> tuple[typing.Annotated[numpy.typing.NDArray[numpy.float64], "[3, 1]"], typing.Annotated[numpy.typing.NDArray[numpy.float64], "[4, 1]"]]:
        ...
    @typing.overload
    def __init__(self, transformation_matrix: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[4, 4]"] = ...) -> None:
        """
        Construct an affine transformation from a 4x4 homogeneous transformation matrix.
        """
    @typing.overload
    def __init__(self, translation: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[3, 1]"] = ..., quaternion: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[4, 1]"] = ...) -> None:
        """
        Construct an affine transformation from a translation [m] and a rotation quaternion in [x, y, z, w] format.
        """
    @typing.overload
    def __init__(self, arg0: Affine) -> None:
        ...
    def __mul__(self, arg0: Affine) -> Affine:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, arg0: tuple) -> None:
        ...
    @property
    def inverse(self) -> Affine:
        """
        The inverse of this transformation.
        """
    @property
    def matrix(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[4, 4]"]:
        """
        This transformation as a 4x4 homogeneous transformation matrix.
        """
    @property
    def quaternion(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[4, 1]"]:
        """
        The rotation component of this transformation as quaternion in [x, y, z, w] format.
        """
    @property
    def translation(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[3, 1]"]:
        """
        The translation component [m] of this transformation.
        """
class BaseCartesianPoseMotion:
    """
    Base class for motions.
    
    Template Args:
        ControlSignalType: Control signal type of the motion. Either franka::Torques,
                           franka::JointVelocities, franka::CartesianVelocities, franka::JointPositions
                           or franka::CartesianPose.
    """
    def add_reaction(self, reaction: CartesianPoseReaction) -> None:
        """
        Add a reaction to the motion.
        
        Reactions are evaluated in every step of the motion and can replace the current motion with a new
        motion.
        
        Args:
            reaction: The reaction to add.
        
        Warning:
            Do not call this function synchronously from a condition, motion function, or reaction callback
            while this motion's reactions are being evaluated. Reaction evaluation holds the reaction-list
            mutex, so doing so would deadlock.
        """
    def register_callback(self, callback: collections.abc.Callable[[RobotState, Duration, Duration, Duration, CartesianPose], None]) -> None:
        """
        Register a callback that is called in every step of the motion.
        
        Args:
            callback: The callback to register. Callbacks are called with the robot state, the time step
                      [s], the relative time [s], the absolute time [s] and the control signal computed in
                      this step.
        """
    @property
    def reactions(self) -> list[CartesianPoseReaction]:
        """
        Currently registered reactions of the motion.
        """
class BaseCartesianVelocityMotion:
    """
    Base class for motions.
    
    Template Args:
        ControlSignalType: Control signal type of the motion. Either franka::Torques,
                           franka::JointVelocities, franka::CartesianVelocities, franka::JointPositions
                           or franka::CartesianPose.
    """
    def add_reaction(self, reaction: CartesianVelocityReaction) -> None:
        """
        Add a reaction to the motion.
        
        Reactions are evaluated in every step of the motion and can replace the current motion with a new
        motion.
        
        Args:
            reaction: The reaction to add.
        
        Warning:
            Do not call this function synchronously from a condition, motion function, or reaction callback
            while this motion's reactions are being evaluated. Reaction evaluation holds the reaction-list
            mutex, so doing so would deadlock.
        """
    def register_callback(self, callback: collections.abc.Callable[[RobotState, Duration, Duration, Duration, CartesianVelocities], None]) -> None:
        """
        Register a callback that is called in every step of the motion.
        
        Args:
            callback: The callback to register. Callbacks are called with the robot state, the time step
                      [s], the relative time [s], the absolute time [s] and the control signal computed in
                      this step.
        """
    @property
    def reactions(self) -> list[CartesianVelocityReaction]:
        """
        Currently registered reactions of the motion.
        """
class BaseJointPositionMotion:
    """
    Base class for motions.
    
    Template Args:
        ControlSignalType: Control signal type of the motion. Either franka::Torques,
                           franka::JointVelocities, franka::CartesianVelocities, franka::JointPositions
                           or franka::CartesianPose.
    """
    def add_reaction(self, reaction: JointPositionReaction) -> None:
        """
        Add a reaction to the motion.
        
        Reactions are evaluated in every step of the motion and can replace the current motion with a new
        motion.
        
        Args:
            reaction: The reaction to add.
        
        Warning:
            Do not call this function synchronously from a condition, motion function, or reaction callback
            while this motion's reactions are being evaluated. Reaction evaluation holds the reaction-list
            mutex, so doing so would deadlock.
        """
    def register_callback(self, callback: collections.abc.Callable[[RobotState, Duration, Duration, Duration, JointPositions], None]) -> None:
        """
        Register a callback that is called in every step of the motion.
        
        Args:
            callback: The callback to register. Callbacks are called with the robot state, the time step
                      [s], the relative time [s], the absolute time [s] and the control signal computed in
                      this step.
        """
    @property
    def reactions(self) -> list[JointPositionReaction]:
        """
        Currently registered reactions of the motion.
        """
class BaseJointVelocityMotion:
    """
    Base class for motions.
    
    Template Args:
        ControlSignalType: Control signal type of the motion. Either franka::Torques,
                           franka::JointVelocities, franka::CartesianVelocities, franka::JointPositions
                           or franka::CartesianPose.
    """
    def add_reaction(self, reaction: JointVelocityReaction) -> None:
        """
        Add a reaction to the motion.
        
        Reactions are evaluated in every step of the motion and can replace the current motion with a new
        motion.
        
        Args:
            reaction: The reaction to add.
        
        Warning:
            Do not call this function synchronously from a condition, motion function, or reaction callback
            while this motion's reactions are being evaluated. Reaction evaluation holds the reaction-list
            mutex, so doing so would deadlock.
        """
    def register_callback(self, callback: collections.abc.Callable[[RobotState, Duration, Duration, Duration, JointVelocities], None]) -> None:
        """
        Register a callback that is called in every step of the motion.
        
        Args:
            callback: The callback to register. Callbacks are called with the robot state, the time step
                      [s], the relative time [s], the absolute time [s] and the control signal computed in
                      this step.
        """
    @property
    def reactions(self) -> list[JointVelocityReaction]:
        """
        Currently registered reactions of the motion.
        """
class BaseTorqueMotion:
    """
    Base class for motions.
    
    Template Args:
        ControlSignalType: Control signal type of the motion. Either franka::Torques,
                           franka::JointVelocities, franka::CartesianVelocities, franka::JointPositions
                           or franka::CartesianPose.
    """
    def add_reaction(self, reaction: TorqueReaction) -> None:
        """
        Add a reaction to the motion.
        
        Reactions are evaluated in every step of the motion and can replace the current motion with a new
        motion.
        
        Args:
            reaction: The reaction to add.
        
        Warning:
            Do not call this function synchronously from a condition, motion function, or reaction callback
            while this motion's reactions are being evaluated. Reaction evaluation holds the reaction-list
            mutex, so doing so would deadlock.
        """
    def register_callback(self, callback: collections.abc.Callable[[RobotState, Duration, Duration, Duration, Torques], None]) -> None:
        """
        Register a callback that is called in every step of the motion.
        
        Args:
            callback: The callback to register. Callbacks are called with the robot state, the time step
                      [s], the relative time [s], the absolute time [s] and the control signal computed in
                      this step.
        """
    @property
    def reactions(self) -> list[TorqueReaction]:
        """
        Currently registered reactions of the motion.
        """
class BoolFuture:
    """
    A future that will eventually contain a boolean result, e.g. of an asynchronous gripper command.
    """
    def get(self) -> bool:
        """
        Wait for the result and return it. Blocks until the result is available.
        """
    def wait(self, timeout: typing.SupportsFloat | typing.SupportsIndex | None = None) -> bool:
        """
        Wait for the result to become available.
        
        Args:
            timeout: Maximum time to wait [s]. If None, waits indefinitely.
        
        Returns:
            True if the result became available before the timeout expired, False otherwise.
        """
class CartesianImpedanceBase(BaseTorqueMotion):
    """
    Base class for client-side cartesian impedance motions.
    
    This motion implements a cartesian impedance controller on the client side and does not use Franka's
    internal impedance controller. Instead, it uses Franka's internal torque controller and calculates
    the torques itself.
    """
    def get_gains(self) -> CartesianImpedanceGains:
        """
        Get a copy of the current target impedance gains.
        
        Mutating the returned object has no effect on the motion; pass it to setGains to apply changes.
        """
    def get_nullspace_gains(self) -> NullspaceGains:
        """
        Get a copy of the current target nullspace gains.
        
        Mutating the returned object has no effect on the motion; pass it to setNullspaceGains to apply
        changes.
        """
    def set_gains(self, gains: CartesianImpedanceGains) -> None:
        """
        Set the target impedance gains.
        
        The gains are validated and then smoothed in the control loop via exponential interpolation.
        
        Args:
            gains: The new target gains.
        """
    def set_nullspace_gains(self, gains: NullspaceGains) -> None:
        """
        Set the target nullspace gains.
        
        The gains are smoothed in the control loop via exponential interpolation.
        
        Args:
            gains: The new target nullspace gains.
        """
class CartesianImpedanceGains:
    """
    Runtime-adjustable stiffness and damping gains for Cartesian impedance motions.
    """
    @staticmethod
    def diagonal(stiffness: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[6, 1]"], damping: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[6, 1]"] | None = None) -> CartesianImpedanceGains:
        """
        Create gains from per-axis diagonal entries.
        
        Args:
            stiffness: Per-axis stiffness [N/m, Nm/rad], ordered [x, y, z, rx, ry, rz].
            damping: Per-axis damping [Ns/m, Nms/rad], ordered [x, y, z, rx, ry, rz]. If unset, critical
                     damping is used.
        """
    @staticmethod
    def isotropic(translational_stiffness: typing.SupportsFloat | typing.SupportsIndex, rotational_stiffness: typing.SupportsFloat | typing.SupportsIndex, translational_damping: typing.SupportsFloat | typing.SupportsIndex | None = None, rotational_damping: typing.SupportsFloat | typing.SupportsIndex | None = None) -> CartesianImpedanceGains:
        """
        Create gains with uniform translational and rotational components.
        
        Args:
            translational_stiffness: Stiffness applied to all translational axes [N/m].
            rotational_stiffness: Stiffness applied to all rotational axes [Nm/rad].
            translational_damping: Damping applied to all translational axes [Ns/m]. If unset, critical
                                   damping is used.
            rotational_damping: Damping applied to all rotational axes [Nms/rad]. If unset, critical damping
                                is used.
        """
    def __init__(self, translational_stiffness: typing.SupportsFloat | typing.SupportsIndex = 500.0, rotational_stiffness: typing.SupportsFloat | typing.SupportsIndex = 50.0) -> None:
        """
        Construct isotropic gains with critical damping. Use the isotropic or diagonal factory functions for more control over the damping.
        """
    @property
    def damping(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[6, 6]"] | None:
        """
        Cartesian damping matrix. If unset, critical damping is used.
        """
    @damping.setter
    def damping(self, arg0: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[6, 6]"] | None) -> None:
        ...
    @property
    def stiffness(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[6, 6]"]:
        """
        Cartesian stiffness matrix [N/m, Nm/rad], ordered [x, y, z, rx, ry, rz].
        """
    @stiffness.setter
    def stiffness(self, arg0: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[6, 6]"]) -> None:
        ...
class CartesianImpedanceMotion(CartesianImpedanceBase):
    """
    Cartesian impedance motion.
    
    This motion implements a cartesian impedance controller on the client side and does not use Franka's
    internal impedance controller. Instead, it uses Franka's internal torque controller and calculates
    the torques itself.
    
    Analogous to JointImpedanceMotion, this motion regulates toward a fixed target pose (and optional
    target twist) and does not terminate on its own. It runs until it is preempted or stopped.
    """
    def __init__(self, target: Affine, target_twist: Twist | None = None, target_type: ReferenceType = ..., translational_stiffness: typing.SupportsFloat | typing.SupportsIndex = 500, rotational_stiffness: typing.SupportsFloat | typing.SupportsIndex = 50, force_constraints: typing.Annotated[collections.abc.Sequence[typing.SupportsFloat | typing.SupportsIndex | None], "FixedSize(6)"] | None = None, posture_task: PostureTask | None = None, manipulability_task: ManipulabilityTask | None = None, max_delta_tau: typing.SupportsFloat | typing.SupportsIndex = 1.0, lower_joint_limits: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[7, 1]"] | None = None, upper_joint_limits: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[7, 1]"] | None = None, joint_limit_activation_distance: typing.SupportsFloat | typing.SupportsIndex = 0.1, joint_limit_stiffness: typing.SupportsFloat | typing.SupportsIndex = 4.0, joint_limit_damping: typing.SupportsFloat | typing.SupportsIndex = 1.0, joint_limit_max_torque: typing.SupportsFloat | typing.SupportsIndex = 5.0, translational_error_clip: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[3, 1]"] = ..., rotational_error_clip: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[3, 1]"] = ..., friction: FrictionCompensationParams | None = None) -> None:
        """
        Construct a Cartesian impedance motion that regulates toward a fixed target pose.
        
        Like JointImpedanceMotion, this motion does not finish on its own; it keeps regulating toward the target until it is preempted or stopped.
        
        If target_twist is provided, it is interpreted as the desired end-effector twist in the base frame and the damping term acts on twist error rather than damping all motion toward zero.
        
        Cartesian damping is chosen internally as critically damped with respect to the requested stiffness.
        
        The optional posture_task adds a secondary joint-posture objective (a PostureTask) that is projected into the Jacobian nullspace, biasing the redundant arm posture without changing the Cartesian task to first order. Its per-joint stiffness leaves zero-stiffness joints unpushed. manipulability_task adds a manipulability-maximization objective in the same nullspace. At most one of each is supported.
        """
    @property
    def params(self) -> CartesianImpedanceMotionParams:
        ...
    @property
    def target(self) -> Affine:
        """
        The target pose of the motion.
        """
    @property
    def target_twist(self) -> Twist:
        ...
class CartesianImpedanceMotionParams(CartesianImpedanceParams):
    """
    Parameters for the Cartesian impedance motion.
    
    See also:
        CartesianImpedanceBase::Params
    """
    def __init__(self) -> None:
        ...
    @property
    def target_type(self) -> ReferenceType:
        """
        The type of the target reference (relative or absolute).
        """
    @target_type.setter
    def target_type(self, arg0: ReferenceType) -> None:
        ...
class CartesianImpedanceParams:
    """
    Parameters for the impedance motion.
    """
    def __init__(self) -> None:
        ...
    @property
    def damping(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[6, 6]"] | None:
        """
        Cartesian damping matrix. If unset, critical damping is used.
        """
    @damping.setter
    def damping(self, arg0: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[6, 6]"] | None) -> None:
        ...
    @property
    def force_constraints(self) -> typing.Annotated[list[float | None], "FixedSize(6)"]:
        """
        Per-axis force/torque constraints [N, Nm]. nullopt on an axis means unconstrained.
        """
    @force_constraints.setter
    def force_constraints(self, arg0: typing.Annotated[collections.abc.Sequence[typing.SupportsFloat | typing.SupportsIndex | None], "FixedSize(6)"]) -> None:
        ...
    @property
    def friction(self) -> FrictionCompensationParams:
        """
        Per-joint friction feedforward. Defaults to zero (disabled).
        """
    @friction.setter
    def friction(self, arg0: FrictionCompensationParams) -> None:
        ...
    @property
    def nullspace_tasks(self) -> list[PostureTask | ManipulabilityTask]:
        """
        Nullspace objectives.
        
        Each task contributes a joint-space torque that is summed and projected into the Jacobian nullspace.
        At most one task of each concrete type is supported because runtime-adjustable gains are shared by
        task type.
        """
    @nullspace_tasks.setter
    def nullspace_tasks(self, arg0: collections.abc.Sequence[PostureTask | ManipulabilityTask]) -> None:
        ...
    @property
    def rotational_error_clip(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[3, 1]"]:
        """
        Maximum absolute Cartesian orientation error [rad] used by the task-space controller.
        
        The rotational error is clamped elementwise in the base frame before the impedance wrench is
        computed. This bounds the commanded Cartesian torque.
        """
    @rotational_error_clip.setter
    def rotational_error_clip(self, arg0: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[3, 1]"]) -> None:
        ...
    @property
    def safety(self) -> TorqueSafetyParams:
        """
        Shared torque safety limits and soft joint-limit repulsion settings.
        """
    @safety.setter
    def safety(self, arg0: TorqueSafetyParams) -> None:
        ...
    @property
    def stiffness(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[6, 6]"]:
        """
        Cartesian stiffness matrix [N/m, Nm/rad], ordered [x, y, z, rx, ry, rz].
        """
    @stiffness.setter
    def stiffness(self, arg0: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[6, 6]"]) -> None:
        ...
    @property
    def translational_error_clip(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[3, 1]"]:
        """
        Maximum absolute Cartesian position error [m] used by the task-space controller.
        
        The translational error is clamped elementwise before the impedance wrench is computed. This bounds
        the commanded Cartesian force when the reference jumps or contact prevents the end effector from
        reaching the target.
        """
    @translational_error_clip.setter
    def translational_error_clip(self, arg0: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[3, 1]"]) -> None:
        ...
class CartesianImpedanceTrackingMotion(CartesianImpedanceBase):
    """
    Cartesian impedance tracking motion.
    
    This motion keeps the same Cartesian impedance controller alive while reading the latest reference
    from a handle or callback every control cycle.
    """
    def __init__(self, translational_stiffness: typing.SupportsFloat | typing.SupportsIndex = 500, rotational_stiffness: typing.SupportsFloat | typing.SupportsIndex = 50, force_constraints: typing.Annotated[collections.abc.Sequence[typing.SupportsFloat | typing.SupportsIndex | None], "FixedSize(6)"] | None = None, posture_task: PostureTask | None = None, manipulability_task: ManipulabilityTask | None = None, max_delta_tau: typing.SupportsFloat | typing.SupportsIndex = 1.0, lower_joint_limits: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[7, 1]"] | None = None, upper_joint_limits: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[7, 1]"] | None = None, joint_limit_activation_distance: typing.SupportsFloat | typing.SupportsIndex = 0.1, joint_limit_stiffness: typing.SupportsFloat | typing.SupportsIndex = 4.0, joint_limit_damping: typing.SupportsFloat | typing.SupportsIndex = 1.0, joint_limit_max_torque: typing.SupportsFloat | typing.SupportsIndex = 5.0, translational_error_clip: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[3, 1]"] = ..., rotational_error_clip: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[3, 1]"] = ..., gains_time_constant: typing.SupportsFloat | typing.SupportsIndex = 0.1, friction: FrictionCompensationParams | None = None) -> None:
        """
        Construct a dynamic Cartesian impedance tracking controller.
        
        Cartesian damping is chosen internally as critically damped with respect to the requested stiffness.
        The optional posture_task adds a secondary joint-posture objective (a PostureTask) that is projected into the Jacobian nullspace, biasing the redundant arm posture without changing the Cartesian task to first order. Its per-joint stiffness leaves zero-stiffness joints unpushed. manipulability_task adds a manipulability-maximization objective in the same nullspace. Their gains can be retuned at runtime via set_nullspace_gains.
        
        The controller reads target gains each cycle and exponentially
        interpolates toward them with the given time constant, allowing smooth runtime stiffness changes.
        """
    def get_reference(self) -> CartesianReference | None:
        """
        Get a copy of the last published Cartesian reference, or None if no reference has been set yet. Mutating the returned object has no effect on the motion; pass it to set_reference to apply changes.
        """
    def set_reference(self, reference: CartesianReference) -> None:
        """
        Set the Cartesian reference tracked by the controller. The reference is validated and picked up by the control loop in the next cycle.
        """
    @property
    def params(self) -> CartesianImpedanceParams:
        """
        The parameters of the motion.
        """
class CartesianMotion(CartesianWaypointMotion):
    """
    Cartesian motion with a single target.
    """
    def __init__(self, target: CartesianState | RobotPose | Affine, reference_type: ReferenceType = ..., relative_dynamics_factor: RelativeDynamicsFactor | float = 1.0, return_when_finished: bool = True, ee_frame: Affine | None = None) -> None:
        """
        Construct a Cartesian motion.
        
        Args:
            target: The target Cartesian state.
            reference_type: The reference type (absolute or relative). An absolute target is defined in the
                            robot's base frame, a relative target is defined in the current end-effector
                            frame.
            relative_dynamics_factor: The relative dynamics factor for this motion. The factor will get
                                      multiplied with the robot's global dynamics factor to get the actual
                                      dynamics factor for this motion.
            return_when_finished: Whether to end the motion when the target is reached or keep holding the
                                  last target.
            ee_frame: The end-effector frame for which the target is defined. This is a transformation from
                      the configured end-effector frame to the end-effector frame the target is defined for.
        """
    @property
    def reference_type(self) -> ReferenceType:
        """
        The reference type (absolute or relative) of this motion.
        """
    @property
    def target(self) -> CartesianState:
        """
        The target of this motion.
        """
class CartesianPose:
    """
    Stores values for Cartesian pose motion generation.
    """
    def __getstate__(self) -> tuple[typing.Annotated[list[float], "FixedSize(16)"], typing.Any, bool]:
        ...
    def __setstate__(self, arg0: tuple) -> None:
        ...
    @property
    def O_T_EE(self) -> typing.Annotated[list[float], "FixedSize(16)"]:
        """
        Homogeneous transformation :math:`^O{\\mathbf{T}_{EE}}_{d}`, column major, that transforms from the
        end effector frame :math:`EE` to base frame :math:`O`. Equivalently, it is the desired end effector
        pose in base frame.
        """
    @property
    def motion_finished(self) -> bool:
        ...
class CartesianPoseReaction:
    """
    A reaction that can be attached to a motion.
    
    This class defines a reaction in a motion, which can be used to change the motion based on the robot
    state. Reactions consist of a condition and a motion that replaces the current motion immediately if
    the condition is met.
    """
    def __init__(self, condition: Condition | bool, motion: BaseCartesianPoseMotion | None = None) -> None:
        """
        Args:
            condition: The condition that must be met for the reaction to be executed.
            new_motion: The motion that is executed if the condition is met.
        """
    def register_callback(self, callback: collections.abc.Callable[[RobotState, Duration, Duration], None]) -> None:
        """
        Register a callback that is called when the condition of this reaction is met.
        
        Args:
            callback: The callback to register. Callbacks are called with the robot state, the relative time
                      [s] and the absolute time [s].
        """
class CartesianReference:
    """
    Cartesian impedance reference expressed in the base frame.
    """
    def __init__(self, target: Affine = ..., target_twist: Twist | None = None, target_acceleration: TwistAcceleration | None = None) -> None:
        ...
    @property
    def target(self) -> Affine:
        """
        Desired end-effector pose.
        """
    @target.setter
    def target(self, arg0: Affine) -> None:
        ...
    @property
    def target_acceleration(self) -> TwistAcceleration | None:
        """
        Desired end-effector acceleration in the base frame.
        
        When present, the controller adds a model-based inertial feedforward wrench Lambda(q) *
        target_acceleration before mapping through J^T.
        """
    @target_acceleration.setter
    def target_acceleration(self, arg0: TwistAcceleration | None) -> None:
        ...
    @property
    def target_twist(self) -> Twist | None:
        """
        Desired end-effector twist in the base frame.
        
        When present, the damping term acts on twist error rather than resisting all motion toward zero.
        """
    @target_twist.setter
    def target_twist(self, arg0: Twist | None) -> None:
        ...
class CartesianState:
    """
    Cartesian state of a robot.
    
    This class encapsulates the cartesian state of a robot, which comprises the end effector pose and
    the end effector velocity.
    """
    def __getstate__(self) -> tuple[RobotPose, RobotVelocity]:
        ...
    @typing.overload
    def __init__(self, pose: RobotPose | Affine) -> None:
        ...
    @typing.overload
    def __init__(self, pose: RobotPose | Affine, velocity: RobotVelocity | Twist) -> None:
        """
        Args:
            pose: The pose of the end effector.
            velocity: The velocity of the end effector.
        """
    @typing.overload
    def __init__(self, arg0: CartesianState | RobotPose | Affine) -> None:
        ...
    def __repr__(self) -> str:
        ...
    def __rmul__(self, arg0: Affine) -> CartesianState:
        ...
    def __setstate__(self, arg0: tuple) -> None:
        ...
    def change_end_effector_frame(self, transform: Affine) -> CartesianState:
        """
        Change the end effector frame of the state by the given affine transform.
        
        Args:
            transform: The pose of the new end-effector in the frame of the old end-effector.
        
        Returns:
            The state with a new end-effector frame.
        """
    def transform_with(self, transform: Affine) -> CartesianState:
        """
        Transform the frame of the state by applying the given affine transform.
        
        Args:
            transform: The transformation to apply.
        
        Returns:
            The state after the transformation.
        """
    @property
    def pose(self) -> RobotPose:
        """
        Pose component of the state.
        """
    @property
    def velocity(self) -> RobotVelocity:
        """
        Velocity component of the state.
        """
class CartesianStopMotion(BaseCartesianPoseMotion):
    """
    Stop motion for cartesian pose control mode.
    """
    def __init__(self, relative_dynamics_factor: RelativeDynamicsFactor | float = 1.0) -> None:
        """
        Args:
            relative_dynamics_factor: Relative dynamics factor for this stop motion.
        """
    @property
    def relative_dynamics_factor(self) -> RelativeDynamicsFactor:
        """
        The relative dynamics factor of this motion.
        """
class CartesianVelocities:
    """
    Stores values for Cartesian velocity motion generation.
    
    The Cartesian velocity of the end-effector is expressed in a frame parallel to the fixed/base frame,
    whose origin is the same as the end-effector frame. Rotations are thus expressed around the end-
    effector and parallel to the base frame.
    """
    def __getstate__(self) -> tuple[typing.Annotated[list[float], "FixedSize(6)"], typing.Any, bool]:
        ...
    def __setstate__(self, arg0: tuple) -> None:
        ...
    @property
    def O_dP_EE(self) -> typing.Annotated[list[float], "FixedSize(6)"]:
        """
        Cartesian velocity with respect to the o-frame "base frame O" with :math:`(\\dot x, \\dot y, \\dot z)`
        in :math:`[m/s]` and :math:`(\\omega_x, \\omega_y, \\omega_z)` in :math:`[rad/s]`.
        """
    @property
    def elbow(self) -> typing.Annotated[list[float], "FixedSize(2)"]:
        """
        Elbow configuration.
        
        The values of the array are:
        
        - ``elbow[0]``: Position of the 3rd joint [rad].
        - ``elbow[1]``: Flip direction of the elbow (4th joint): +1 if the 4th joint is above, 0 if it is at, and -1 if it is below :math:`\\alpha = -0.467` rad.
        """
    @property
    def motion_finished(self) -> bool:
        ...
class CartesianVelocityMotion(CartesianVelocityWaypointMotion):
    """
    Cartesian velocity motion with a single target velocity.
    """
    def __init__(self, target: RobotVelocity | Twist, duration: Duration = ..., relative_dynamics_factor: RelativeDynamicsFactor | float = 1.0, ee_frame: Affine | None = None) -> None:
        """
        Construct a Cartesian velocity motion.
        
        Args:
            target: The target Cartesian velocity.
            duration: For how long the target is held after it has been reached. Default is 1s.
            relative_dynamics_factor: The relative dynamics factor for this motion. The factor will get
                                      multiplied with the robot's global dynamics factor to get the actual
                                      dynamics factor for this motion.
            ee_frame: The end-effector frame for which the target is defined. This is a transformation from
                      the configured end-effector frame to the end-effector frame the target is defined for.
        """
    @property
    def duration(self) -> Duration:
        """
        For how long the target is held after it has been reached.
        """
    @property
    def target(self) -> RobotVelocity:
        """
        The target of this motion.
        """
class CartesianVelocityReaction:
    """
    A reaction that can be attached to a motion.
    
    This class defines a reaction in a motion, which can be used to change the motion based on the robot
    state. Reactions consist of a condition and a motion that replaces the current motion immediately if
    the condition is met.
    """
    def __init__(self, condition: Condition | bool, motion: BaseCartesianVelocityMotion | None = None) -> None:
        """
        Args:
            condition: The condition that must be met for the reaction to be executed.
            new_motion: The motion that is executed if the condition is met.
        """
    def register_callback(self, callback: collections.abc.Callable[[RobotState, Duration, Duration], None]) -> None:
        """
        Register a callback that is called when the condition of this reaction is met.
        
        Args:
            callback: The callback to register. Callbacks are called with the robot state, the relative time
                      [s] and the absolute time [s].
        """
class CartesianVelocityStopMotion(BaseCartesianVelocityMotion):
    """
    Stop motion for cartesian velocity control mode.
    """
    def __init__(self, relative_dynamics_factor: RelativeDynamicsFactor | float = 1.0) -> None:
        """
        Args:
            relative_dynamics_factor: Relative dynamics factor for this stop motion.
        """
    @property
    def relative_dynamics_factor(self) -> RelativeDynamicsFactor:
        """
        The relative dynamics factor of this motion.
        """
class CartesianVelocityWaypoint:
    """
    A waypoint with a target and optional parameters.
    
    Template Args:
        TargetType: The type of the target.
    """
    def __init__(self, target: RobotVelocity | Twist, relative_dynamics_factor: RelativeDynamicsFactor | float = 1.0, minimum_time: Duration | None = None, hold_target_duration: Duration = ..., max_total_duration: Duration | None = None) -> None:
        ...
    @property
    def hold_target_duration(self) -> Duration:
        """
        For how long to hold the target of this waypoint after it has been reached.
        """
    @property
    def max_total_duration(self) -> Duration | None:
        """
        The maximum time to try reaching this waypoint before moving on to the next waypoint. Default is
        infinite.
        """
    @property
    def minimum_time(self) -> Duration | None:
        """
        The minimum time to reach this waypoint. This value is ignored when the effective relative dynamics
        factor has max_dynamics() set.
        """
    @property
    def relative_dynamics_factor(self) -> RelativeDynamicsFactor:
        """
        The relative dynamics factor for this waypoint. This factor will get multiplied with the robot's
        global dynamics factor and the motion dynamics factor to get the actual dynamics factor for this
        waypoint.
        """
    @property
    def target(self) -> RobotVelocity:
        """
        The target of this waypoint.
        """
class CartesianVelocityWaypointMotion(BaseCartesianVelocityMotion):
    """
    Cartesian velocity waypoint motion.
    
    This motion follows multiple consecutive cartesian velocity targets in a time-optimal way.
    """
    def __init__(self, waypoints: collections.abc.Sequence[CartesianVelocityWaypoint], ee_frame: Affine | None = None, relative_dynamics_factor: RelativeDynamicsFactor | float = 1.0) -> None:
        """
        Args:
            waypoints: Waypoints to follow.
            relative_dynamics_factor: The relative dynamics factor for this motion. This factor will get
                                      multiplied with the robot's global dynamics factor to get the actual
                                      dynamics factor for this motion.
            ee_frame: The end-effector frame for which the target is defined. This is a transformation from
                      the configured end-effector frame to the end-effector frame the target is defined for.
        """
    @property
    def ee_frame(self) -> Affine:
        """
        The end-effector frame for which the targets are defined.
        """
    @property
    def relative_dynamics_factor(self) -> RelativeDynamicsFactor:
        """
        The relative dynamics factor of this motion.
        """
    @property
    def waypoints(self) -> list[CartesianVelocityWaypoint]:
        """
        The waypoints this motion follows.
        """
class CartesianWaypoint:
    """
    A position waypoint with a target and optional parameters.
    
    Template Args:
        TargetType: The type of the target.
    """
    def __init__(self, target: CartesianState | RobotPose | Affine, reference_type: ReferenceType = ..., relative_dynamics_factor: RelativeDynamicsFactor | float = 1.0, minimum_time: Duration | None = None, hold_target_duration: Duration = ..., max_total_duration: Duration | None = None) -> None:
        ...
    @property
    def hold_target_duration(self) -> Duration:
        """
        For how long to hold the target of this waypoint after it has been reached.
        """
    @property
    def max_total_duration(self) -> Duration | None:
        """
        The maximum time to try reaching this waypoint before moving on to the next waypoint. Default is
        infinite.
        """
    @property
    def minimum_time(self) -> Duration | None:
        """
        The minimum time to reach this waypoint. This value is ignored when the effective relative dynamics
        factor has max_dynamics() set.
        """
    @property
    def reference_type(self) -> ReferenceType:
        """
        The reference type (absolute or relative). A relative waypoint is resolved against the preceding
        waypoint's target. The first relative waypoint is resolved against the motion's initial commanded
        position. This remains true if max_total_duration advances past a waypoint before it is reached.
        """
    @property
    def relative_dynamics_factor(self) -> RelativeDynamicsFactor:
        """
        The relative dynamics factor for this waypoint. This factor will get multiplied with the robot's
        global dynamics factor and the motion dynamics factor to get the actual dynamics factor for this
        waypoint.
        """
    @property
    def target(self) -> CartesianState:
        """
        The target of this waypoint.
        """
class CartesianWaypointMotion(BaseCartesianPoseMotion):
    """
    Cartesian waypoint motion.
    
    This motion follows multiple consecutive cartesian targets in a time-optimal way.
    """
    def __init__(self, waypoints: collections.abc.Sequence[CartesianWaypoint], ee_frame: Affine | None = None, relative_dynamics_factor: RelativeDynamicsFactor | float = 1.0, return_when_finished: bool = True) -> None:
        """
        Args:
            waypoints: Waypoints to follow.
            relative_dynamics_factor: The relative dynamics factor for this motion. This factor will get
                                      multiplied with the robot's global dynamics factor to get the actual
                                      dynamics factor for this motion.
            return_when_finished: Whether to end the motion when the last waypoint is reached or keep
                                  holding the last target.
            ee_frame: The end-effector frame for which the target is defined. This is a transformation from
                      the configured end-effector frame to the end-effector frame the target is defined for.
        """
    @property
    def ee_frame(self) -> Affine:
        """
        The end-effector frame for which the targets are defined.
        """
    @property
    def relative_dynamics_factor(self) -> RelativeDynamicsFactor:
        """
        The relative dynamics factor of this motion.
        """
    @property
    def return_when_finished(self) -> bool:
        """
        Whether the motion ends when the last waypoint is reached or keeps holding the last target.
        """
    @property
    def waypoints(self) -> list[CartesianWaypoint]:
        """
        The waypoints this motion follows.
        """
class CommandException(builtins.Exception):
    """
    CommandException is thrown if an error occurs during command execution.
    """
class Condition:
    """
    A condition on the robot state.
    
    This class defines a condition on the robot state, which can be used to define a condition for a
    reaction in a motion. Conditions support logical operations (conjunction, disjunction, equality, and
    negation) and can be combined to form more complex conditions.
    """
    __hash__: typing.ClassVar[None] = None  # type: ignore[assignment]
    def __and__(self, arg0: Condition | bool) -> Condition:
        ...
    def __eq__(self, arg0: Condition | bool) -> Condition:  # type: ignore[override]
        ...
    def __init__(self, constant_value: bool) -> None:
        """
        Implicit constructor for constant conditions.
        
        Args:
            constant_value: The constant value of the condition.
        """
    def __invert__(self) -> Condition:
        ...
    def __ne__(self, arg0: Condition | bool) -> Condition:  # type: ignore[override]
        ...
    def __or__(self, arg0: Condition | bool) -> Condition:
        ...
    def __rand__(self, arg0: bool) -> Condition:
        ...
    def __repr__(self) -> str:
        ...
    def __ror__(self, arg0: bool) -> Condition:
        ...
class ControlException(builtins.Exception):
    """
    ControlException is thrown if an error occurs during motion generation or torque control. The
    exception holds a vector with the last received robot states. The number of recorded states can be
    configured in the Robot constructor.
    """
class ControlSignalType:
    """
    Type of control signal.
    
    Members:
    
      Torques
    
      JointVelocities
    
      JointPositions
    
      CartesianVelocities
    
      CartesianPose
    """
    CartesianPose: typing.ClassVar[ControlSignalType]  # value = <ControlSignalType.CartesianPose: 4>
    CartesianVelocities: typing.ClassVar[ControlSignalType]  # value = <ControlSignalType.CartesianVelocities: 3>
    JointPositions: typing.ClassVar[ControlSignalType]  # value = <ControlSignalType.JointPositions: 2>
    JointVelocities: typing.ClassVar[ControlSignalType]  # value = <ControlSignalType.JointVelocities: 1>
    Torques: typing.ClassVar[ControlSignalType]  # value = <ControlSignalType.Torques: 0>
    __members__: typing.ClassVar[dict[str, ControlSignalType]]  # value = {'Torques': <ControlSignalType.Torques: 0>, 'JointVelocities': <ControlSignalType.JointVelocities: 1>, 'JointPositions': <ControlSignalType.JointPositions: 2>, 'CartesianVelocities': <ControlSignalType.CartesianVelocities: 3>, 'CartesianPose': <ControlSignalType.CartesianPose: 4>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: typing.SupportsInt | typing.SupportsIndex) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: typing.SupportsInt | typing.SupportsIndex) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class ControllerMode:
    """
    Available controller modes for a franka::Robot.
    
    Members:
    
      JointImpedance
    
      CartesianImpedance
    """
    CartesianImpedance: typing.ClassVar[ControllerMode]  # value = <ControllerMode.CartesianImpedance: 1>
    JointImpedance: typing.ClassVar[ControllerMode]  # value = <ControllerMode.JointImpedance: 0>
    __members__: typing.ClassVar[dict[str, ControllerMode]]  # value = {'JointImpedance': <ControllerMode.JointImpedance: 0>, 'CartesianImpedance': <ControllerMode.CartesianImpedance: 1>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: typing.SupportsInt | typing.SupportsIndex) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: typing.SupportsInt | typing.SupportsIndex) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class DoubleDynamicsLimit:
    """
    A template class representing a dynamics limit with a maximum value.
    
    This class provides functionality to store and manage a dynamic limit, including setting and getting
    the value of the limit while ensuring that it cannot be written while the robot is in control.
    
    Template Args:
        LimitType: The type of the limit value (e.g., double, int).
    """
    def __repr__(self) -> str:
        ...
    def get(self) -> float:
        """
        Get the current value of the limit.
        
        Retrieves the current value stored in this limit.
        
        Returns:
            The current value of the limit.
        """
    def set(self, value: typing.SupportsFloat | typing.SupportsIndex) -> None:
        """
        Set a new value for the limit.
        
        Sets the value of the limit, but only if the robot is not in control. Throws a runtime_error if the
        condition for writing to the limit is not met.
        
        Args:
            value: The new value to set for the limit.
        
        Raises:
            std::runtime_error: if the limit cannot be set due to the robot being in control.
        """
    @property
    def desc(self) -> str:
        """
        Description of this limit.
        
        This string provides a human-readable description of the limit, such as "joint velocity" or "maximum
        load".
        """
    @property
    def max(self) -> float:
        """
        The maximum value this limit can take as defined by Franka.
        
        This value represents the maximum boundary for the limit, beyond which the value cannot be set.
        """
class Duration:
    """
    Represents a duration with millisecond resolution.
    """
    def __add__(self, arg0: Duration) -> Duration:
        ...
    def __getstate__(self) -> tuple[int]:
        ...
    def __iadd__(self, arg0: Duration) -> Duration:
        ...
    def __imul__(self, arg0: typing.SupportsInt | typing.SupportsIndex) -> Duration:
        ...
    @typing.overload
    def __init__(self) -> None:
        """
        Creates a new Duration instance with zero milliseconds.
        """
    @typing.overload
    def __init__(self, arg0: typing.SupportsInt | typing.SupportsIndex) -> None:
        """
        Creates a new Duration instance from the given number of milliseconds.
        
        Args:
            milliseconds: Number of milliseconds.
        """
    def __isub__(self, arg0: Duration) -> Duration:
        ...
    def __itruediv__(self, arg0: typing.SupportsInt | typing.SupportsIndex) -> Duration:
        ...
    def __mul__(self, arg0: typing.SupportsInt | typing.SupportsIndex) -> Duration:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, arg0: tuple) -> None:
        ...
    def __sub__(self, arg0: Duration) -> Duration:
        ...
    def __truediv__(self, arg0: typing.SupportsInt | typing.SupportsIndex) -> Duration:
        ...
    def to_msec(self) -> int:
        """
        Returns the stored duration in :math:`[ms]`.
        
        Returns:
            Duration in :math:`[ms]`.
        """
    def to_sec(self) -> float:
        """
        Returns the stored duration in :math:`[s]`.
        
        Returns:
            Duration in :math:`[s]`.
        """
class ElbowState:
    """
    Elbow state of the robot.
    
    This class encapsulates the elbow state of a robot, which comprises the position of the 3rd joint
    and the flip direction of the 4th joint. For details see https://frankarobotics.github.io/libfranka/
    0.15.3/structfranka_1_1RobotState.html#a43485841c427d70e7f36a912cc3116d1
    """
    def __getstate__(self) -> tuple[float, FlipDirection | None]:
        ...
    @typing.overload
    def __init__(self, joint_3_pos: typing.SupportsFloat | typing.SupportsIndex, joint_4_flip: FlipDirection | None = None) -> None:
        """
        Construct an elbow state with the given joint position and optional flip direction.
        
        Args:
            joint_3_pos: The position of the 3rd joint.
            joint_4_flip: The flip direction of the 4th joint.
        """
    @typing.overload
    def __init__(self, arg0: ElbowState) -> None:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, arg0: tuple) -> None:
        ...
    @property
    def joint_3_pos(self) -> float:
        """
        The position of the 3rd joint.
        """
    @property
    def joint_4_flip(self) -> FlipDirection | None:
        """
        The flip direction of the 4th joint.
        """
class Errors:
    """
    Enumerates errors that can occur while controlling a franka::Robot.
    """
    def __getstate__(self) -> tuple[bool, bool, bool, bool, bool, bool, bool, bool, bool, bool, bool, bool, bool, bool, bool, bool, bool, bool, bool, bool, bool, bool, bool, bool, bool, bool, bool, bool, bool, bool, bool, bool, bool, bool, bool, bool, bool, bool, bool, bool, bool]:
        ...
    def __init__(self) -> None:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, arg0: tuple) -> None:
        ...
    @property
    def base_acceleration_initialization_timeout(self) -> bool:
        """
        True if the gravity vector could not be initialized by measureing the base acceleration.
        """
    @property
    def base_acceleration_invalid_reading(self) -> bool:
        """
        True if the base acceleration O_ddP_O cannot be determined.
        """
    @property
    def cartesian_motion_generator_acceleration_discontinuity(self) -> bool:
        """
        True if commanded acceleration in Cartesian motion generators is discontinuous (target values are
        too far apart).
        """
    @property
    def cartesian_motion_generator_elbow_limit_violation(self) -> bool:
        """
        True if an external Cartesian motion generator would move into an elbow limit.
        """
    @property
    def cartesian_motion_generator_elbow_sign_inconsistent(self) -> bool:
        """
        True if commanded elbow values in Cartesian motion generators are inconsistent.
        """
    @property
    def cartesian_motion_generator_joint_acceleration_discontinuity(self) -> bool:
        """
        True if the joint acceleration in Cartesian motion generators is discontinuous after IK calculation.
        """
    @property
    def cartesian_motion_generator_joint_position_limits_violation(self) -> bool:
        """
        True if the joint position limits would be exceeded after IK calculation.
        """
    @property
    def cartesian_motion_generator_joint_velocity_discontinuity(self) -> bool:
        """
        True if the joint velocity in Cartesian motion generators is discontinuous after IK calculation.
        """
    @property
    def cartesian_motion_generator_joint_velocity_limits_violation(self) -> bool:
        """
        True if the joint velocity limits would be exceeded after IK calculation.
        """
    @property
    def cartesian_motion_generator_start_elbow_invalid(self) -> bool:
        """
        True if the first elbow value in Cartesian motion generators is too far from initial one.
        """
    @property
    def cartesian_motion_generator_velocity_discontinuity(self) -> bool:
        """
        True if commanded velocity in Cartesian motion generators is discontinuous (target values are too
        far apart).
        """
    @property
    def cartesian_motion_generator_velocity_limits_violation(self) -> bool:
        """
        True if an external Cartesian motion generator would move with too high velocity.
        """
    @property
    def cartesian_position_limits_violation(self) -> bool:
        """
        True if the robot moved past any of the virtual walls.
        """
    @property
    def cartesian_position_motion_generator_invalid_frame(self) -> bool:
        """
        True if the Cartesian pose is not a valid transformation matrix.
        """
    @property
    def cartesian_position_motion_generator_start_pose_invalid(self) -> bool:
        """
        True if an external Cartesian position motion generator was started with a pose too far from the
        current pose.
        """
    @property
    def cartesian_reflex(self) -> bool:
        """
        True if a collision was detected, i.e. the robot exceeded a torque threshold in a Cartesian motion.
        """
    @property
    def cartesian_spline_motion_generator_violation(self) -> bool:
        """
        True if the generated motion violates a joint limit.
        """
    @property
    def cartesian_velocity_profile_safety_violation(self) -> bool:
        """
        True if Cartesian velocity profile for internal motions was exceeded.
        """
    @property
    def cartesian_velocity_violation(self) -> bool:
        """
        True if the robot exceeded Cartesian velocity limits.
        """
    @property
    def communication_constraints_violation(self) -> bool:
        """
        True if minimum network communication quality could not be held during a motion.
        """
    @property
    def controller_torque_discontinuity(self) -> bool:
        """
        True if the torque set by the external controller is discontinuous.
        """
    @property
    def force_control_safety_violation(self) -> bool:
        """
        True if the robot exceeded safety threshold during force control.
        """
    @property
    def force_controller_desired_force_tolerance_violation(self) -> bool:
        """
        True if desired force exceeds the safety thresholds.
        """
    @property
    def instability_detected(self) -> bool:
        """
        True if an instability is detected.
        """
    @property
    def joint_motion_generator_acceleration_discontinuity(self) -> bool:
        """
        True if commanded acceleration in joint motion generators is discontinuous (target values are too
        far apart).
        """
    @property
    def joint_motion_generator_position_limits_violation(self) -> bool:
        """
        True if an external joint motion generator would move into a joint limit.
        """
    @property
    def joint_motion_generator_velocity_discontinuity(self) -> bool:
        """
        True if commanded velocity in joint motion generators is discontinuous (target values are too far
        apart).
        """
    @property
    def joint_motion_generator_velocity_limits_violation(self) -> bool:
        """
        True if an external joint motion generator exceeded velocity limits.
        """
    @property
    def joint_move_in_wrong_direction(self) -> bool:
        """
        True if the robot is in joint position limits violation error and the user guides the robot further
        towards the limit.
        """
    @property
    def joint_p2p_insufficient_torque_for_planning(self) -> bool:
        """
        True if the robot is overloaded for the required motion.
        
        Applies only to motions started from Desk.
        """
    @property
    def joint_position_limits_violation(self) -> bool:
        """
        True if the robot moved past the joint limits.
        """
    @property
    def joint_position_motion_generator_start_pose_invalid(self) -> bool:
        """
        True if an external joint position motion generator was started with a pose too far from the current
        pose.
        """
    @property
    def joint_reflex(self) -> bool:
        """
        True if a collision was detected, i.e. the robot exceeded a torque threshold in a joint motion.
        """
    @property
    def joint_velocity_violation(self) -> bool:
        """
        True if the robot exceeded joint velocity limits.
        """
    @property
    def joint_via_motion_generator_planning_joint_limit_violation(self) -> bool:
        """
        True if the generated motion violates a joint limit.
        """
    @property
    def max_goal_pose_deviation_violation(self) -> bool:
        """
        True if internal motion generator did not reach the goal pose.
        """
    @property
    def max_path_pose_deviation_violation(self) -> bool:
        """
        True if internal motion generator deviated from the path.
        """
    @property
    def power_limit_violation(self) -> bool:
        """
        True if commanded values would result in exceeding the power limit.
        """
    @property
    def self_collision_avoidance_violation(self) -> bool:
        """
        True if the robot would have collided with itself.
        """
    @property
    def start_elbow_sign_inconsistent(self) -> bool:
        """
        True if the start elbow sign was inconsistent.
        
        Applies only to motions started from Desk.
        """
    @property
    def tau_j_range_violation(self) -> bool:
        """
        True if the measured torque signal is out of the safe range.
        """
class Exception(builtins.Exception):
    """
    Base class for all exceptions used by `libfranka`.
    """
class FlipDirection:
    """
    Flip direction of a joint.
    
    Members:
    
      Negative : The joint angle is negative.
    
      Neutral : The joint angle is zero.
    
      Positive : The joint angle is positive.
    """
    Negative: typing.ClassVar[FlipDirection]  # value = <FlipDirection.Negative: -1>
    Neutral: typing.ClassVar[FlipDirection]  # value = <FlipDirection.Neutral: 0>
    Positive: typing.ClassVar[FlipDirection]  # value = <FlipDirection.Positive: 1>
    __members__: typing.ClassVar[dict[str, FlipDirection]]  # value = {'Negative': <FlipDirection.Negative: -1>, 'Neutral': <FlipDirection.Neutral: 0>, 'Positive': <FlipDirection.Positive: 1>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: typing.SupportsInt | typing.SupportsIndex) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: typing.SupportsInt | typing.SupportsIndex) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class Frame:
    """
    Enumerates the seven joints, the flange, and the end effector of a robot.
    
    Members:
    
      Joint1
    
      Joint2
    
      Joint3
    
      Joint4
    
      Joint5
    
      Joint6
    
      Joint7
    
      Flange
    
      EndEffector
    
      Stiffness
    """
    EndEffector: typing.ClassVar[Frame]  # value = <Frame.EndEffector: 8>
    Flange: typing.ClassVar[Frame]  # value = <Frame.Flange: 7>
    Joint1: typing.ClassVar[Frame]  # value = <Frame.Joint1: 0>
    Joint2: typing.ClassVar[Frame]  # value = <Frame.Joint2: 1>
    Joint3: typing.ClassVar[Frame]  # value = <Frame.Joint3: 2>
    Joint4: typing.ClassVar[Frame]  # value = <Frame.Joint4: 3>
    Joint5: typing.ClassVar[Frame]  # value = <Frame.Joint5: 4>
    Joint6: typing.ClassVar[Frame]  # value = <Frame.Joint6: 5>
    Joint7: typing.ClassVar[Frame]  # value = <Frame.Joint7: 6>
    Stiffness: typing.ClassVar[Frame]  # value = <Frame.Stiffness: 9>
    __members__: typing.ClassVar[dict[str, Frame]]  # value = {'Joint1': <Frame.Joint1: 0>, 'Joint2': <Frame.Joint2: 1>, 'Joint3': <Frame.Joint3: 2>, 'Joint4': <Frame.Joint4: 3>, 'Joint5': <Frame.Joint5: 4>, 'Joint6': <Frame.Joint6: 5>, 'Joint7': <Frame.Joint7: 6>, 'Flange': <Frame.Flange: 7>, 'EndEffector': <Frame.EndEffector: 8>, 'Stiffness': <Frame.Stiffness: 9>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: typing.SupportsInt | typing.SupportsIndex) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: typing.SupportsInt | typing.SupportsIndex) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class FrictionCompensationParams:
    """
    Per-joint friction feedforward settings for torque-control motions.
    """
    def __init__(self, coulomb: typing.Annotated[collections.abc.Sequence[typing.SupportsFloat | typing.SupportsIndex], "FixedSize(7)"] = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0], viscous: typing.Annotated[collections.abc.Sequence[typing.SupportsFloat | typing.SupportsIndex], "FixedSize(7)"] = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0], max_torque: typing.Annotated[collections.abc.Sequence[typing.SupportsFloat | typing.SupportsIndex], "FixedSize(7)"] = [1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0], velocity_epsilon: typing.SupportsFloat | typing.SupportsIndex = 0.03) -> None:
        ...
    @property
    def coulomb(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 1]"]:
        """
        Coulomb friction compensation gains in [Nm].
        """
    @coulomb.setter
    def coulomb(self, arg0: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[7, 1]"]) -> None:
        ...
    @property
    def max_torque(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 1]"]:
        """
        Absolute per-joint clamp for friction compensation in [Nm].
        """
    @max_torque.setter
    def max_torque(self, arg0: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[7, 1]"]) -> None:
        ...
    @property
    def velocity_epsilon(self) -> float:
        """
        Velocity scale for the smooth Coulomb sign transition in [rad/s].
        """
    @velocity_epsilon.setter
    def velocity_epsilon(self, arg0: typing.SupportsFloat | typing.SupportsIndex) -> None:
        ...
    @property
    def viscous(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 1]"]:
        """
        Viscous friction compensation gains in [Nms/rad].
        """
    @viscous.setter
    def viscous(self, arg0: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[7, 1]"]) -> None:
        ...
class Gripper:
    """
    A wrapper around the franka::Gripper class that adds asynchronous functionality.
    """
    def __init__(self, fci_hostname: str) -> None:
        """
        Establishes a connection with a gripper connected to a robot.
        
        Args:
            franka_address: IP/hostname of the robot the gripper is connected to.
        
        Raises:
            NetworkException: if the connection is unsuccessful.
            IncompatibleVersionException: if this version of `libfranka` is not supported.
        """
    def grasp(self, width: typing.SupportsFloat | typing.SupportsIndex, speed: typing.SupportsFloat | typing.SupportsIndex, force: typing.SupportsFloat | typing.SupportsIndex, epsilon_inner: typing.SupportsFloat | typing.SupportsIndex = 0.005, epsilon_outer: typing.SupportsFloat | typing.SupportsIndex = 0.005) -> bool:
        """
        Grasps an object.
        
        An object is considered grasped if the distance :math:`d` between the gripper fingers satisfies
        :math:`(\\text{width} - \\text{epsilon_inner}) < d < (\\text{width} + \\text{epsilon_outer})`.
        
        Args:
            width: Size of the object to grasp in :math:`[m]`.
            speed: Closing speed in :math:`[\\frac{m}{s}]`.
            force: Grasping force in :math:`[N]`.
            epsilon_inner: Maximum tolerated deviation when the actual grasped width is smaller than
                                the commanded grasp width.
            epsilon_outer: Maximum tolerated deviation when the actual grasped width is larger than the
                                commanded grasp width.
        
        Returns:
            True if an object has been grasped, false otherwise.
        
        Raises:
            CommandException: if an error occurred.
            NetworkException: if the connection is lost, e.g. after a timeout.
        """
    def grasp_async(self, width: typing.SupportsFloat | typing.SupportsIndex, speed: typing.SupportsFloat | typing.SupportsIndex, force: typing.SupportsFloat | typing.SupportsIndex, epsilon_inner: typing.SupportsFloat | typing.SupportsIndex = 0.005, epsilon_outer: typing.SupportsFloat | typing.SupportsIndex = 0.005) -> BoolFuture:
        """
        Asynchronous variant of the grasp function.
        
        Args:
            width: Size of the object to grasp in [m].
            speed: Closing speed in [m/s].
            force: Grasping force in [N].
            epsilon_inner: Maximum tolerated deviation when the actual grasped width is smaller than the
                           commanded grasp width.
            epsilon_outer: Maximum tolerated deviation when the actual grasped width is larger than the
                           commanded grasp width.
        
        Returns:
            Future that becomes ready when the grasp is finished. Contains true if an object has been
            grasped, false otherwise.
        """
    def homing(self) -> bool:
        """
        Performs homing of the gripper.
        
        After changing the gripper fingers, a homing needs to be done. This is needed to estimate the
        maximum grasping width.
        
        Returns:
            True if command was successful, false otherwise.
        
        Raises:
            CommandException: if an error occurred.
            NetworkException: if the connection is lost, e.g. after a timeout.
        
        See also:
            GripperState for the maximum grasping width.
        """
    def homing_async(self) -> BoolFuture:
        """
        Asynchronous variant of the homing function.
        
        Returns:
            A future that becomes ready when the homing is finished. Contains true if the homing was
            successful.
        """
    def move(self, width: typing.SupportsFloat | typing.SupportsIndex, speed: typing.SupportsFloat | typing.SupportsIndex) -> bool:
        """
        Moves the gripper fingers to a specified width.
        
        Args:
            width: Intended opening width in :math:`[m]`.
            speed: Closing speed in :math:`[\\frac{m}{s}]`.
        
        Returns:
            True if command was successful, false otherwise.
        
        Raises:
            CommandException: if an error occurred.
            NetworkException: if the connection is lost, e.g. after a timeout.
        """
    def move_async(self, width: typing.SupportsFloat | typing.SupportsIndex, speed: typing.SupportsFloat | typing.SupportsIndex) -> BoolFuture:
        """
        Asynchronous variant of the move function.
        
        Args:
            width: Intended opening width in [m].
            speed: Speed of the movement in [m/s].
        
        Returns:
            Future that becomes ready when the movement is finished. Contains true if the movement was
            successful.
        """
    def open(self, speed: typing.SupportsFloat | typing.SupportsIndex) -> bool:
        """
        Opens the gripper fully.
        
        Args:
            speed: Speed of the movement in [m/s].
        
        Returns:
            True if the gripper was opened successfully.
        """
    def open_async(self, speed: typing.SupportsFloat | typing.SupportsIndex) -> BoolFuture:
        """
        Asynchronous variant of the open function.
        
        Args:
            speed: Speed of the movement in [m/s].
        
        Returns:
            Future that becomes ready when the gripper is fully opened. Contains true if the gripper was
            opened successfully.
        """
    def stop(self) -> bool:
        """
        Stops a currently running gripper move or grasp.
        
        Returns:
            True if command was successful, false otherwise.
        
        Raises:
            CommandException: if an error occurred.
            NetworkException: if the connection is lost, e.g. after a timeout.
        """
    def stop_async(self) -> BoolFuture:
        """
        Asynchronous variant of the stop function.
        
        Returns:
            A future that becomes ready when the stop is finished. Contains true if the stop was successful.
        """
    @property
    def is_grasped(self) -> bool:
        """
        Whether the gripper is grasping
        """
    @property
    def max_width(self) -> float:
        """
        Maximum width of the gripper [m]
        """
    @property
    def server_version(self) -> int:
        """
        Returns the software version reported by the connected server.
        
        Returns:
            Software version of the connected server.
        """
    @property
    def state(self) -> GripperState:
        """
        Current gripper state.
        """
    @property
    def width(self) -> float:
        """
        Current opening width of the gripper [m]
        """
class GripperException(builtins.Exception):
    """
    Exception thrown by the gripper class.
    """
class GripperState:
    """
    Describes the gripper state.
    """
    def __getstate__(self) -> tuple[float, float, bool, int, Duration]:
        ...
    def __setstate__(self, arg0: tuple) -> None:
        ...
    @property
    def is_grasped(self) -> bool:
        """
        Indicates whether an object is currently grasped.
        """
    @property
    def max_width(self) -> float:
        """
        Maximum gripper opening width. This parameter is estimated by homing the gripper. After changing the
        gripper fingers, a homing needs to be done. Unit: :math:`[m]`.
        
        See also:
            Gripper::homing.
        """
    @property
    def temperature(self) -> int:
        """
        Current gripper temperature. Unit: :math:`[°C]`.
        """
    @property
    def time(self) -> Duration:
        """
        Strictly monotonically increasing timestamp since robot start.
        """
    @property
    def width(self) -> float:
        """
        Current gripper opening width. Unit: :math:`[m]`.
        """
class IncompatibleVersionException(builtins.Exception):
    """
    IncompatibleVersionException is thrown if the robot does not support this version of libfranka.
    """
class InvalidMotionTypeException(builtins.Exception):
    """
    Exception thrown when an invalid motion type is used.
    
    This exception is thrown when a motion is asynchronously executed and a new motion of a different
    type is set before the previous one finished.
    """
class InvalidOperationException(builtins.Exception):
    """
    InvalidOperationException is thrown if an operation cannot be performed.
    """
class JointImpedanceBase(BaseTorqueMotion):
    """
    Base class for client-side joint impedance motions.
    
    This class computes joint torques from a joint-space spring-damper law plus optional torque
    offset/model compensation. Subclasses implement nextCommandImpl and call computeCommand with their
    current reference.
    """
    def get_cartesian_gains(self) -> CartesianImpedanceGains:
        """
        Get a copy of the current target Cartesian shaping gains.
        
        Mutating the returned object has no effect on the motion; pass it to setCartesianGains to apply
        changes.
        """
    def get_gains(self) -> JointImpedanceGains:
        """
        Get a copy of the current target impedance gains.
        
        Mutating the returned object has no effect on the motion; pass it to setGains to apply changes.
        """
    def set_cartesian_gains(self, gains: CartesianImpedanceGains) -> None:
        """
        Set the target Cartesian shaping gains.
        
        The gains are validated and then smoothed in the control loop via exponential interpolation.
        
        Args:
            gains: The new target Cartesian gains.
        """
    def set_gains(self, gains: JointImpedanceGains) -> None:
        """
        Set the target impedance gains.
        
        The gains are validated and then smoothed in the control loop via exponential interpolation.
        
        Args:
            gains: The new target gains.
        """
class JointImpedanceGains:
    """
    Runtime-adjustable stiffness and damping gains for joint impedance motions.
    """
    def __init__(self, stiffness: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[7, 1]"] | None = None, damping: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[7, 1]"] | None = None) -> None:
        """
        Construct joint impedance gains. If stiffness is unset, the default stiffness is used. If damping is unset (None), critical damping is tracked against the current stiffness in the control loop.
        """
    @property
    def damping(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 1]"] | None:
        """
        Joint damping gains [Nms/rad]. If unset, the controller tracks critical damping, 2*sqrt(stiffness),
        against the current (smoothed) stiffness every control cycle, so damping stays critical through gain
        transitions.
        """
    @damping.setter
    def damping(self, arg0: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[7, 1]"] | None) -> None:
        ...
    @property
    def stiffness(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 1]"]:
        """
        Joint stiffness gains [Nm/rad].
        """
    @stiffness.setter
    def stiffness(self, arg0: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[7, 1]"]) -> None:
        ...
class JointImpedanceMotion(JointImpedanceBase):
    """
    Client-side joint impedance controller.
    
    This motion uses Franka's torque interface and regulates toward a constant joint target (and
    optional target velocity). It does not terminate on its own; it runs until it is preempted or
    stopped.
    """
    def __init__(self, target: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[7, 1]"], target_velocity: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[7, 1]"] | None = None, stiffness: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[7, 1]"] | None = None, damping: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[7, 1]"] | None = None, cartesian_stiffness: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[6, 1]"] | None = None, cartesian_damping: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[6, 1]"] | None = None, constant_torque_offset: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[7, 1]"] | None = None, lower_joint_limits: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[7, 1]"] | None = None, upper_joint_limits: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[7, 1]"] | None = None, compensate_coriolis: bool = True, max_delta_tau: typing.SupportsFloat | typing.SupportsIndex = 1.0, joint_limit_activation_distance: typing.SupportsFloat | typing.SupportsIndex = 0.1, joint_limit_stiffness: typing.SupportsFloat | typing.SupportsIndex = 4.0, joint_limit_damping: typing.SupportsFloat | typing.SupportsIndex = 1.0, joint_limit_max_torque: typing.SupportsFloat | typing.SupportsIndex = 5.0, friction: FrictionCompensationParams | None = None) -> None:
        """
        Construct a joint impedance controller regulating toward a fixed joint target.
        
        This motion does not finish on its own; it keeps regulating toward the target until it is
        preempted or stopped.
        
        If damping is not set, critical damping is chosen with respect to the given stiffness. The
        optional cartesian_stiffness/cartesian_damping parameters add a Cartesian-space spring-damper
        term that is projected through the current Jacobian. The joint-limit parameters configure a
        soft repulsion torque that activates near the joint limits (only if both lower_joint_limits
        and upper_joint_limits are set).
        """
    @property
    def params(self) -> JointImpedanceParams:
        """
        The parameters of the motion.
        """
    @property
    def target(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 1]"]:
        """
        The target joint positions of the motion [rad].
        """
    @property
    def target_velocity(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 1]"]:
        """
        The target joint velocities of the motion [rad/s].
        """
class JointImpedanceParams:
    """
    Parameters for joint impedance motions.
    """
    def __init__(self) -> None:
        ...
    @property
    def cartesian_gains(self) -> CartesianImpedanceGains | None:
        """
        Optional Cartesian-space stiffness/damping projected through the current Jacobian.
        """
    @cartesian_gains.setter
    def cartesian_gains(self, arg0: CartesianImpedanceGains | None) -> None:
        ...
    @property
    def compensate_coriolis(self) -> bool:
        """
        Compensate Coriolis forces using the robot model.
        """
    @compensate_coriolis.setter
    def compensate_coriolis(self, arg0: bool) -> None:
        ...
    @property
    def constant_torque_offset(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 1]"]:
        """
        Constant torque offset added to every command in [Nm].
        """
    @constant_torque_offset.setter
    def constant_torque_offset(self, arg0: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[7, 1]"]) -> None:
        ...
    @property
    def damping(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 1]"] | None:
        """
        Joint damping gains in [Nms/rad]. If unset, critical damping is tracked against the
         current (smoothed) stiffness.
        """
    @damping.setter
    def damping(self, arg0: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[7, 1]"] | None) -> None:
        ...
    @property
    def error_clip(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 1]"]:
        """
        Maximum absolute joint position error [rad] used by the joint-space controller.
        """
    @error_clip.setter
    def error_clip(self, arg0: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[7, 1]"]) -> None:
        ...
    @property
    def friction(self) -> FrictionCompensationParams:
        """
        Joint friction compensation settings.
        """
    @friction.setter
    def friction(self, arg0: FrictionCompensationParams) -> None:
        ...
    @property
    def safety(self) -> TorqueSafetyParams:
        """
        Shared torque safety limits and soft joint-limit repulsion settings.
        """
    @safety.setter
    def safety(self, arg0: TorqueSafetyParams) -> None:
        ...
    @property
    def stiffness(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 1]"]:
        """
        Joint stiffness gains in [Nm/rad].
        """
    @stiffness.setter
    def stiffness(self, arg0: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[7, 1]"]) -> None:
        ...
class JointImpedanceTrackingMotion(JointImpedanceBase):
    """
    Client-side joint impedance controller with a dynamic online reference.
    
    This motion keeps the same controller alive while reading the latest valid joint reference from a
    handle or callback each control cycle.
    """
    def __init__(self, stiffness: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[7, 1]"] | None = None, damping: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[7, 1]"] | None = None, cartesian_stiffness: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[6, 1]"] | None = None, cartesian_damping: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[6, 1]"] | None = None, constant_torque_offset: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[7, 1]"] | None = None, lower_joint_limits: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[7, 1]"] | None = None, upper_joint_limits: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[7, 1]"] | None = None, compensate_coriolis: bool = True, max_delta_tau: typing.SupportsFloat | typing.SupportsIndex = 1.0, joint_limit_activation_distance: typing.SupportsFloat | typing.SupportsIndex = 0.1, joint_limit_stiffness: typing.SupportsFloat | typing.SupportsIndex = 4.0, joint_limit_damping: typing.SupportsFloat | typing.SupportsIndex = 1.0, joint_limit_max_torque: typing.SupportsFloat | typing.SupportsIndex = 5.0, friction: FrictionCompensationParams | None = None, gains_time_constant: typing.SupportsFloat | typing.SupportsIndex = 0.1) -> None:
        """
        Construct a dynamic joint impedance controller.
        
        Any constant_torque_offset configured here is added to the per-cycle torque_feedforward values.
        
        The controller reads target gains each cycle and exponentially
        interpolates toward them with the given time constant, allowing smooth runtime stiffness/damping changes.
        """
    def get_reference(self) -> JointReference | None:
        """
        Get a copy of the last published joint reference, or None if no reference has been set yet. Mutating the returned object has no effect on the motion; pass it to set_reference to apply changes.
        """
    def set_reference(self, reference: JointReference) -> None:
        """
        Set the joint reference tracked by the controller. The reference is validated and picked up by the control loop in the next cycle.
        """
    @property
    def params(self) -> JointImpedanceParams:
        """
        The parameters of the motion.
        """
    @property
    def target(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 1]"]:
        """
        The target joint positions of the motion [rad].
        """
    @property
    def target_velocity(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 1]"]:
        """
        The target joint velocities of the motion [rad/s].
        """
class JointMotion(JointWaypointMotion):
    """
    Joint motion with a single target.
    """
    def __init__(self, target: JointState | list[float] | numpy.ndarray, reference_type: ReferenceType = ..., relative_dynamics_factor: RelativeDynamicsFactor | float = 1.0, return_when_finished: bool = True) -> None:
        """
        Args:
            target: The target joint state.
            reference_type: The reference type (absolute or relative). An absolute target is defined in the
                            robot's base frame, a relative target is defined relative to the current joint
                            position.
            relative_dynamics_factor: The relative dynamics factor for this motion. The factor will get
                                      multiplied with the robot's global dynamics factor to get the actual
                                      dynamics factor for this motion.
            return_when_finished: Whether to end the motion when the target is reached or keep holding the
                                  last target.
        """
    @property
    def reference_type(self) -> ReferenceType:
        """
        The reference type (absolute or relative) of this motion.
        """
    @property
    def target(self) -> JointState:
        """
        The target of this motion.
        """
class JointPositionReaction:
    """
    A reaction that can be attached to a motion.
    
    This class defines a reaction in a motion, which can be used to change the motion based on the robot
    state. Reactions consist of a condition and a motion that replaces the current motion immediately if
    the condition is met.
    """
    def __init__(self, condition: Condition | bool, motion: BaseJointPositionMotion | None = None) -> None:
        """
        Args:
            condition: The condition that must be met for the reaction to be executed.
            new_motion: The motion that is executed if the condition is met.
        """
    def register_callback(self, callback: collections.abc.Callable[[RobotState, Duration, Duration], None]) -> None:
        """
        Register a callback that is called when the condition of this reaction is met.
        
        Args:
            callback: The callback to register. Callbacks are called with the robot state, the relative time
                      [s] and the absolute time [s].
        """
class JointPositions:
    """
    Stores values for joint position motion generation.
    """
    def __getstate__(self) -> tuple[typing.Annotated[list[float], "FixedSize(7)"], bool]:
        ...
    def __setstate__(self, arg0: tuple) -> None:
        ...
    @property
    def motion_finished(self) -> bool:
        ...
    @property
    def q(self) -> typing.Annotated[list[float], "FixedSize(7)"]:
        """
        Desired joint angles in [rad].
        """
class JointReference:
    """
    Joint-space reference for joint impedance motions.
    
    The impedance controller tracks the joint position and velocity reference and adds the optional per-
    cycle feedforward torque term to the commanded torques.
    """
    def __init__(self, q: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[7, 1]"] | None = None, dq: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[7, 1]"] | None = None, tau_ff: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[7, 1]"] | None = None) -> None:
        """
        Construct a joint reference. Unset components default to zero.
        """
    @property
    def dq(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 1]"]:
        """
        Desired joint velocities [rad/s].
        """
    @dq.setter
    def dq(self, arg0: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[7, 1]"]) -> None:
        ...
    @property
    def q(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 1]"]:
        """
        Desired joint positions [rad].
        """
    @q.setter
    def q(self, arg0: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[7, 1]"]) -> None:
        ...
    @property
    def tau_ff(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 1]"]:
        """
        Feedforward torque added to the commanded torques [Nm].
        """
    @tau_ff.setter
    def tau_ff(self, arg0: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[7, 1]"]) -> None:
        ...
class JointState:
    """
    Joint state of a robot.
    
    This class encapsulates the joint state of a robot, which comprises the joint positions and the
    joint velocities.
    """
    def __getstate__(self) -> tuple[typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 1]"], typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 1]"]]:
        ...
    @typing.overload
    def __init__(self, position: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[7, 1]"]) -> None:
        """
        Construct a joint state with the given joint positions and zero velocities.
        
        Args:
            position: The joint positions.
        """
    @typing.overload
    def __init__(self, position: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[7, 1]"], velocity: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[7, 1]"]) -> None:
        """
        Args:
            position: The joint positions.
            velocity: The joint velocities.
        """
    @typing.overload
    def __init__(self, arg0: JointState | list[float] | numpy.ndarray) -> None:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, arg0: tuple) -> None:
        ...
    @property
    def position(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 1]"]:
        """
        The position component of the state.
        """
    @property
    def velocity(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 1]"]:
        """
        The velocity component of the state.
        """
class JointStopMotion(BaseJointPositionMotion):
    """
    Stop motion for joint position control mode.
    """
    def __init__(self, relative_dynamics_factor: RelativeDynamicsFactor | float = 1.0) -> None:
        """
        Args:
            relative_dynamics_factor: Relative dynamics factor for this stop motion.
        """
    @property
    def relative_dynamics_factor(self) -> RelativeDynamicsFactor:
        """
        The relative dynamics factor of this motion.
        """
class JointVelocities:
    """
    Stores values for joint velocity motion generation.
    """
    def __getstate__(self) -> tuple[typing.Annotated[list[float], "FixedSize(7)"], bool]:
        ...
    def __setstate__(self, arg0: tuple) -> None:
        ...
    @property
    def dq(self) -> typing.Annotated[list[float], "FixedSize(7)"]:
        """
        Desired joint velocities in :math:`[\\frac{rad}{s}]`.
        """
    @property
    def motion_finished(self) -> bool:
        ...
class JointVelocityMotion(JointVelocityWaypointMotion):
    """
    Joint velocity motion with a single target.
    """
    def __init__(self, target: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[7, 1]"], duration: Duration = ..., relative_dynamics_factor: RelativeDynamicsFactor | float = 1.0) -> None:
        """
        Args:
            target: The target joint velocity.
            duration: For how long the target is held after it has been reached. Default is 1s.
            relative_dynamics_factor: The relative dynamics factor for this motion. The factor will get
                                      multiplied with the robot's global dynamics factor to get the actual
                                      dynamics factor for this motion.
        """
    @property
    def duration(self) -> Duration:
        """
        For how long the target is held after it has been reached.
        """
    @property
    def target(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 1]"]:
        """
        The target of this motion.
        """
class JointVelocityReaction:
    """
    A reaction that can be attached to a motion.
    
    This class defines a reaction in a motion, which can be used to change the motion based on the robot
    state. Reactions consist of a condition and a motion that replaces the current motion immediately if
    the condition is met.
    """
    def __init__(self, condition: Condition | bool, motion: BaseJointVelocityMotion | None = None) -> None:
        """
        Args:
            condition: The condition that must be met for the reaction to be executed.
            new_motion: The motion that is executed if the condition is met.
        """
    def register_callback(self, callback: collections.abc.Callable[[RobotState, Duration, Duration], None]) -> None:
        """
        Register a callback that is called when the condition of this reaction is met.
        
        Args:
            callback: The callback to register. Callbacks are called with the robot state, the relative time
                      [s] and the absolute time [s].
        """
class JointVelocityStopMotion(BaseJointVelocityMotion):
    """
    Stop motion for joint velocity control mode.
    """
    def __init__(self, relative_dynamics_factor: RelativeDynamicsFactor | float = 1.0) -> None:
        """
        Args:
            relative_dynamics_factor: Relative dynamics factor for this stop motion.
        """
    @property
    def relative_dynamics_factor(self) -> RelativeDynamicsFactor:
        """
        The relative dynamics factor of this motion.
        """
class JointVelocityWaypoint:
    """
    A waypoint with a target and optional parameters.
    
    Template Args:
        TargetType: The type of the target.
    """
    def __init__(self, target: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[7, 1]"], relative_dynamics_factor: RelativeDynamicsFactor | float = 1.0, minimum_time: Duration | None = None, hold_target_duration: Duration = ..., max_total_duration: Duration | None = None) -> None:
        ...
    @property
    def hold_target_duration(self) -> Duration:
        """
        For how long to hold the target of this waypoint after it has been reached.
        """
    @property
    def max_total_duration(self) -> Duration | None:
        """
        The maximum time to try reaching this waypoint before moving on to the next waypoint. Default is
        infinite.
        """
    @property
    def minimum_time(self) -> Duration | None:
        """
        The minimum time to reach this waypoint. This value is ignored when the effective relative dynamics
        factor has max_dynamics() set.
        """
    @property
    def relative_dynamics_factor(self) -> RelativeDynamicsFactor:
        """
        The relative dynamics factor for this waypoint. This factor will get multiplied with the robot's
        global dynamics factor and the motion dynamics factor to get the actual dynamics factor for this
        waypoint.
        """
    @property
    def target(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 1]"]:
        """
        The target of this waypoint.
        """
class JointVelocityWaypointMotion(BaseJointVelocityMotion):
    """
    Joint velocity waypoint motion.
    
    This motion follows multiple joint velocity waypoints in a time-optimal way.
    """
    def __init__(self, waypoints: collections.abc.Sequence[JointVelocityWaypoint], relative_dynamics_factor: RelativeDynamicsFactor | float = 1.0) -> None:
        """
        Args:
            waypoints: Joint waypoints to follow.
            relative_dynamics_factor: The relative dynamics factor for this motion. The factor will get
                                      multiplied with the robot's global dynamics factor to get the actual
                                      dynamics factor for this motion.
        """
    @property
    def relative_dynamics_factor(self) -> RelativeDynamicsFactor:
        """
        The relative dynamics factor of this motion.
        """
    @property
    def waypoints(self) -> list[JointVelocityWaypoint]:
        """
        The waypoints this motion follows.
        """
class JointWaypoint:
    """
    A position waypoint with a target and optional parameters.
    
    Template Args:
        TargetType: The type of the target.
    """
    def __init__(self, target: JointState | list[float] | numpy.ndarray, reference_type: ReferenceType = ..., relative_dynamics_factor: RelativeDynamicsFactor | float = 1.0, minimum_time: Duration | None = None, hold_target_duration: Duration = ..., max_total_duration: Duration | None = None) -> None:
        ...
    @property
    def hold_target_duration(self) -> Duration:
        """
        For how long to hold the target of this waypoint after it has been reached.
        """
    @property
    def max_total_duration(self) -> Duration | None:
        """
        The maximum time to try reaching this waypoint before moving on to the next waypoint. Default is
        infinite.
        """
    @property
    def minimum_time(self) -> Duration | None:
        """
        The minimum time to reach this waypoint. This value is ignored when the effective relative dynamics
        factor has max_dynamics() set.
        """
    @property
    def reference_type(self) -> ReferenceType:
        """
        The reference type (absolute or relative). A relative waypoint is resolved against the preceding
        waypoint's target. The first relative waypoint is resolved against the motion's initial commanded
        position. This remains true if max_total_duration advances past a waypoint before it is reached.
        """
    @property
    def relative_dynamics_factor(self) -> RelativeDynamicsFactor:
        """
        The relative dynamics factor for this waypoint. This factor will get multiplied with the robot's
        global dynamics factor and the motion dynamics factor to get the actual dynamics factor for this
        waypoint.
        """
    @property
    def target(self) -> JointState:
        """
        The target of this waypoint.
        """
class JointWaypointMotion(BaseJointPositionMotion):
    """
    Joint waypoint motion.
    
    This motion follows multiple joint waypoints in a time-optimal way.
    """
    def __init__(self, waypoints: collections.abc.Sequence[JointWaypoint], relative_dynamics_factor: RelativeDynamicsFactor | float = 1.0, return_when_finished: bool = True) -> None:
        """
        Args:
            waypoints: Joint waypoints to follow.
            relative_dynamics_factor: The relative dynamics factor for this motion. The factor will get
                                      multiplied with the robot's global dynamics factor to get the actual
                                      dynamics factor for this motion.
            return_when_finished: Whether to end the motion when the last waypoint is reached or keep
                                  holding the last target.
        """
    @property
    def relative_dynamics_factor(self) -> RelativeDynamicsFactor:
        """
        The relative dynamics factor of this motion.
        """
    @property
    def return_when_finished(self) -> bool:
        """
        Whether the motion ends when the last waypoint is reached or keeps holding the last target.
        """
    @property
    def waypoints(self) -> list[JointWaypoint]:
        """
        The waypoints this motion follows.
        """
class ManipulabilityTask:
    """
    Manipulability maximization objective projected into the Cartesian nullspace.
    """
    def __init__(self, gain: typing.SupportsFloat | typing.SupportsIndex, damping: typing.SupportsFloat | typing.SupportsIndex = 0.0, max_torque: typing.SupportsFloat | typing.SupportsIndex | None = None) -> None:
        ...
    @property
    def damping(self) -> float:
        """
        Joint damping applied to this task before projection [Nms/rad].
        """
    @damping.setter
    def damping(self, arg0: typing.SupportsFloat | typing.SupportsIndex) -> None:
        ...
    @property
    def gain(self) -> float:
        """
        Gain applied to the manipulability gradient.
        """
    @gain.setter
    def gain(self, arg0: typing.SupportsFloat | typing.SupportsIndex) -> None:
        ...
    @property
    def max_torque(self) -> float | None:
        """
        Per-joint absolute torque clamp for this task [Nm]. Unset means no clamp.
        """
    @max_torque.setter
    def max_torque(self, arg0: typing.SupportsFloat | typing.SupportsIndex | None) -> None:
        ...
class Measure:
    """
    A measure on the robot state.
    
    This class defines a measure on the robot state, which can be used to define a condition for a
    reaction in a motion. Measures support arithmetic operations (``+``, ``-``, ``*``, ``/``, ``^``) and
    comparisons (``==``, ``!=``, ``<``, ``>``, ``<=``, ``>=``) can be combined to form more complex
    measures.
    """
    ABS_TIME: typing.ClassVar[Measure]  # value = Measure.ABS_TIME
    FORCE_X: typing.ClassVar[Measure]  # value = F_x
    FORCE_Y: typing.ClassVar[Measure]  # value = F_y
    FORCE_Z: typing.ClassVar[Measure]  # value = F_z
    REL_TIME: typing.ClassVar[Measure]  # value = Measure.REL_TIME
    __hash__: typing.ClassVar[None] = None  # type: ignore[assignment]
    @typing.overload
    def __add__(self, arg0: Measure) -> Measure:
        ...
    @typing.overload
    def __add__(self, arg0: typing.SupportsFloat | typing.SupportsIndex) -> Measure:
        ...
    @typing.overload  # type: ignore[override]
    def __eq__(self, arg0: Measure) -> Condition:
        ...
    @typing.overload  # type: ignore[override]
    def __eq__(self, arg0: typing.SupportsFloat | typing.SupportsIndex) -> Condition:
        ...
    @typing.overload
    def __ge__(self, arg0: Measure) -> Condition:
        ...
    @typing.overload
    def __ge__(self, arg0: typing.SupportsFloat | typing.SupportsIndex) -> Condition:
        ...
    @typing.overload
    def __gt__(self, arg0: Measure) -> Condition:
        ...
    @typing.overload
    def __gt__(self, arg0: typing.SupportsFloat | typing.SupportsIndex) -> Condition:
        ...
    @typing.overload
    def __le__(self, arg0: Measure) -> Condition:
        ...
    @typing.overload
    def __le__(self, arg0: typing.SupportsFloat | typing.SupportsIndex) -> Condition:
        ...
    @typing.overload
    def __lt__(self, arg0: Measure) -> Condition:
        ...
    @typing.overload
    def __lt__(self, arg0: typing.SupportsFloat | typing.SupportsIndex) -> Condition:
        ...
    @typing.overload
    def __mul__(self, arg0: Measure) -> Measure:
        ...
    @typing.overload
    def __mul__(self, arg0: typing.SupportsFloat | typing.SupportsIndex) -> Measure:
        ...
    @typing.overload  # type: ignore[override]
    def __ne__(self, arg0: Measure) -> Condition:
        ...
    @typing.overload  # type: ignore[override]
    def __ne__(self, arg0: typing.SupportsFloat | typing.SupportsIndex) -> Condition:
        ...
    def __neg__(self) -> Measure:
        ...
    @typing.overload
    def __pow__(self, arg0: Measure) -> Measure:
        ...
    @typing.overload
    def __pow__(self, arg0: typing.SupportsFloat | typing.SupportsIndex) -> Measure:
        ...
    def __radd__(self, arg0: typing.SupportsFloat | typing.SupportsIndex) -> Measure:
        ...
    def __repr__(self) -> str:
        ...
    def __rmul__(self, arg0: typing.SupportsFloat | typing.SupportsIndex) -> Measure:
        ...
    def __rpow__(self, arg0: typing.SupportsFloat | typing.SupportsIndex) -> Measure:
        ...
    def __rsub__(self, arg0: typing.SupportsFloat | typing.SupportsIndex) -> Measure:
        ...
    def __rtruediv__(self, arg0: typing.SupportsFloat | typing.SupportsIndex) -> Measure:
        ...
    @typing.overload
    def __sub__(self, arg0: Measure) -> Measure:
        ...
    @typing.overload
    def __sub__(self, arg0: typing.SupportsFloat | typing.SupportsIndex) -> Measure:
        ...
    @typing.overload
    def __truediv__(self, arg0: Measure) -> Measure:
        ...
    @typing.overload
    def __truediv__(self, arg0: typing.SupportsFloat | typing.SupportsIndex) -> Measure:
        ...
class Model:
    """
    A wrapper around franka::Model that uses Eigen types.
    
    This class exposes the same functionality as franka::Model, but uses Eigen types for inputs and
    outputs instead of std::array. All 2D arrays are returned as Eigen matrices.
    """
    @typing.overload
    def body_jacobian(self, frame: Frame, state: RobotState) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[6, 7]"]:
        """
        Calculates the body Jacobian in the given frame.
        
        Args:
            frame: The frame for which the Jacobian is computed.
            state: The current robot state.
        
        Returns:
            The 6x7 body Jacobian matrix.
        """
    @typing.overload
    def body_jacobian(self, frame: Frame, q: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[7, 1]"], F_T_EE: Affine, EE_T_K: Affine) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[6, 7]"]:
        """
        Calculates the body Jacobian in the given frame.
        
        Args:
            frame: The frame for which the Jacobian is computed.
            q: Robot joint angles [rad].
            F_T_EE: Transformation from flange to end-effector frame.
            EE_T_K: Transformation from end-effector frame to stiffness frame.
        
        Returns:
            The 6x7 body Jacobian matrix.
        """
    @typing.overload
    def coriolis(self, state: RobotState) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 1]"]:
        """
        Calculates the Coriolis force vector.
        
        Args:
            state: The current robot state.
        
        Returns:
            The Coriolis vector [Nm].
        """
    @typing.overload
    def coriolis(self, q: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[7, 1]"], dq: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[7, 1]"], I_total: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[3, 3]"], m_total: typing.SupportsFloat | typing.SupportsIndex, F_x_Ctotal: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[3, 1]"]) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 1]"]:
        """
        Calculates the Coriolis force vector.
        
        Args:
            q: Robot joint angles [rad].
            dq: Robot joint velocities [rad/s].
            I_total: Combined load and robot inertia [kg·m²].
            m_total: Combined mass of robot and load [kg].
            F_x_Ctotal: Center of mass relative to flange frame [m].
        
        Returns:
            The Coriolis vector [Nm].
        """
    @typing.overload
    def gravity(self, state: RobotState, gravity_earth: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[3, 1]"]) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 1]"]:
        """
        Calculates the gravity vector.
        
        Args:
            state: The current robot state.
            gravity_earth: Gravity vector in base frame [m/s²].
        
        Returns:
            The gravity vector [Nm].
        """
    @typing.overload
    def gravity(self, state: RobotState) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 1]"]:
        """
        Calculates the gravity vector using default gravity direction (0, 0, -9.81).
        
        Args:
            state: The current robot state.
        
        Returns:
            The gravity vector [Nm].
        """
    @typing.overload
    def gravity(self, q: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[7, 1]"], m_total: typing.SupportsFloat | typing.SupportsIndex, F_x_Ctotal: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[3, 1]"], gravity_earth: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[3, 1]"] = ...) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 1]"]:
        """
        Calculates the gravity vector.
        
        Args:
            q: Robot joint angles [rad].
            m_total: Combined mass of robot and load [kg].
            F_x_Ctotal: Center of mass relative to flange frame [m].
            gravity_earth: Gravity vector in base frame [m/s²], default is (0, 0, -9.81).
        
        Returns:
            The gravity vector [Nm].
        """
    @typing.overload
    def mass(self, state: RobotState) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 7]"]:
        """
        Calculates the mass matrix.
        
        Args:
            state: The current robot state.
        
        Returns:
            The 7x7 mass matrix.
        """
    @typing.overload
    def mass(self, q: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[7, 1]"], I_total: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[3, 3]"], m_total: typing.SupportsFloat | typing.SupportsIndex, F_x_Ctotal: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[3, 1]"]) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 7]"]:
        """
        Calculates the mass matrix.
        
        Args:
            q: Robot joint angles [rad].
            I_total: Combined load and robot inertia [kg·m²].
            m_total: Combined mass of robot and load [kg].
            F_x_Ctotal: Center of mass relative to flange frame [m].
        
        Returns:
            The 7x7 mass matrix.
        """
    @typing.overload
    def pose(self, frame: Frame, state: RobotState) -> Affine:
        """
        Calculates the pose of a frame relative to the base frame.
        
        Args:
            frame: The frame whose pose should be returned.
            state: The current robot state.
        
        Returns:
            The pose as an affine transformation matrix.
        """
    @typing.overload
    def pose(self, frame: Frame, q: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[7, 1]"], F_T_EE: Affine, EE_T_K: Affine) -> Affine:
        """
        Calculates the pose of a frame relative to the base frame.
        
        Args:
            frame: The frame whose pose should be returned.
            q: Robot joint angles [rad].
            F_T_EE: Transformation from flange to end-effector frame.
            EE_T_K: Transformation from end-effector frame to stiffness frame.
        
        Returns:
            The pose as an affine transformation matrix.
        """
    @typing.overload
    def zero_jacobian(self, frame: Frame, state: RobotState) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[6, 7]"]:
        """
        Calculates the zero Jacobian in base frame.
        
        Args:
            frame: The frame for which the Jacobian is computed.
            state: The current robot state.
        
        Returns:
            The 6x7 zero Jacobian matrix.
        """
    @typing.overload
    def zero_jacobian(self, frame: Frame, q: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[7, 1]"], F_T_EE: Affine, EE_T_K: Affine) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[6, 7]"]:
        """
        Calculates the zero Jacobian in base frame.
        
        Args:
            frame: The frame for which the Jacobian is computed.
            q: Robot joint angles [rad].
            F_T_EE: Transformation from flange to end-effector frame.
            EE_T_K: Transformation from end-effector frame to stiffness frame.
        
        Returns:
            The 6x7 zero Jacobian matrix.
        """
class ModelException(builtins.Exception):
    """
    ModelException is thrown if an error occurs when loading the model library.
    """
class MotionReuseException(builtins.Exception):
    """
    Exception thrown when a motion is started more than once.
    
    Motions maintain internal state, hence they must not be reused. Create a new motion instance for
    every execution instead.
    """
class NetworkException(builtins.Exception):
    """
    NetworkException is thrown if a connection to the robot cannot be established, or when a timeout
    occurs.
    """
class NullspaceGains:
    """
    Runtime-adjustable gains for a nullspace task.
    """
    def __init__(self) -> None:
        ...
    @property
    def manipulability_damping(self) -> float:
        """
        Joint damping applied to the manipulability task before projection [Nms/rad].
        """
    @manipulability_damping.setter
    def manipulability_damping(self, arg0: typing.SupportsFloat | typing.SupportsIndex) -> None:
        ...
    @property
    def manipulability_gain(self) -> float:
        """
        Gain applied to the manipulability gradient.
        """
    @manipulability_gain.setter
    def manipulability_gain(self, arg0: typing.SupportsFloat | typing.SupportsIndex) -> None:
        ...
    @property
    def manipulability_max_torque(self) -> float | None:
        """
        Absolute torque clamp for the manipulability task [Nm]. Unset means no clamp.
        """
    @manipulability_max_torque.setter
    def manipulability_max_torque(self, arg0: typing.SupportsFloat | typing.SupportsIndex | None) -> None:
        ...
    @property
    def posture_damping(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 1]"] | None:
        """
        Per-joint posture damping [Nms/rad]. Accepts a scalar (applied to all joints), a 7-vector, or None for critical damping.
        """
    @posture_damping.setter
    def posture_damping(self, arg1: typing.SupportsFloat | typing.SupportsIndex | typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[7, 1]"] | None) -> None:
        ...
    @property
    def posture_max_torque(self) -> float | None:
        """
        Absolute torque clamp for the posture task [Nm]. Unset means no clamp.
        """
    @posture_max_torque.setter
    def posture_max_torque(self, arg0: typing.SupportsFloat | typing.SupportsIndex | None) -> None:
        ...
    @property
    def posture_stiffness(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 1]"]:
        """
        Per-joint posture stiffness [Nm/rad]. Accepts a scalar (applied to all joints) or a 7-vector.
        """
    @posture_stiffness.setter
    def posture_stiffness(self, arg1: typing.SupportsFloat | typing.SupportsIndex | typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[7, 1]"]) -> None:
        ...
class PostureTask:
    """
    Joint-posture objective projected into the Cartesian nullspace.
    """
    @typing.overload
    def __init__(self, target: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[7, 1]"], stiffness: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[7, 1]"], damping: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[7, 1]"] | None = None, max_torque: typing.SupportsFloat | typing.SupportsIndex | None = None) -> None:
        ...
    @typing.overload
    def __init__(self, target: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[7, 1]"], stiffness: typing.SupportsFloat | typing.SupportsIndex, damping: typing.SupportsFloat | typing.SupportsIndex | None = None, max_torque: typing.SupportsFloat | typing.SupportsIndex | None = None) -> None:
        """
        Convenience constructor applying the same scalar gains to all joints.
        """
    @property
    def damping(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 1]"] | None:
        """
        Per-joint posture damping in [Nms/rad].
        
        If unset, the controller uses critical damping, 2*sqrt(stiffness), per joint.
        """
    @damping.setter
    def damping(self, arg0: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[7, 1]"] | None) -> None:
        ...
    @property
    def max_torque(self) -> float | None:
        """
        Per-joint absolute torque clamp for this task [Nm]. Unset means no clamp.
        """
    @max_torque.setter
    def max_torque(self, arg0: typing.SupportsFloat | typing.SupportsIndex | None) -> None:
        ...
    @property
    def stiffness(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 1]"]:
        """
        Per-joint posture stiffness in [Nm/rad].
        
        A joint with zero stiffness is not pushed by this task. Note that the task torque is projected into
        the Jacobian nullspace, so pushing a single joint still moves all joints that participate in the
        self-motion.
        """
    @stiffness.setter
    def stiffness(self, arg0: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[7, 1]"]) -> None:
        ...
    @property
    def target(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 1]"]:
        """
        Preferred joint posture [rad].
        """
    @target.setter
    def target(self, arg0: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[7, 1]"]) -> None:
        ...
class ProtocolException(builtins.Exception):
    """
    ProtocolException is thrown if the robot returns an incorrect message.
    """
class ReactionRecursionException(builtins.Exception):
    """
    Exception thrown when the reaction recursion limit (16) is reached.
    """
class RealtimeConfig:
    """
    Used to decide whether to enforce realtime mode for a control loop thread.
    
    See also:
        Robot::Robot
    
    Members:
    
      Enforce
    
      Ignore
    """
    Enforce: typing.ClassVar[RealtimeConfig]  # value = <RealtimeConfig.Enforce: 0>
    Ignore: typing.ClassVar[RealtimeConfig]  # value = <RealtimeConfig.Ignore: 1>
    __members__: typing.ClassVar[dict[str, RealtimeConfig]]  # value = {'Enforce': <RealtimeConfig.Enforce: 0>, 'Ignore': <RealtimeConfig.Ignore: 1>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: typing.SupportsInt | typing.SupportsIndex) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: typing.SupportsInt | typing.SupportsIndex) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class RealtimeException(builtins.Exception):
    """
    RealtimeException is thrown if realtime priority cannot be set.
    """
class ReferenceType:
    """
    Enum class for reference types.
    
    This enum class defines the reference types for motions (absolute or relative).
    
    Members:
    
      Relative : The target is given relative to the robot's state when the motion starts.
    
      Absolute : The target is given in the robot's base frame (or as absolute joint positions).
    """
    Absolute: typing.ClassVar[ReferenceType]  # value = <ReferenceType.Absolute: 0>
    Relative: typing.ClassVar[ReferenceType]  # value = <ReferenceType.Relative: 1>
    __members__: typing.ClassVar[dict[str, ReferenceType]]  # value = {'Relative': <ReferenceType.Relative: 1>, 'Absolute': <ReferenceType.Absolute: 0>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: typing.SupportsInt | typing.SupportsIndex) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: typing.SupportsInt | typing.SupportsIndex) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class RelativeDynamicsFactor:
    """
    Relative dynamics factors
    
    This class encapsulates the relative dynamics factors, which are used to scale the maximum velocity,
    acceleration, and jerk of a trajectory.
    """
    MAX_DYNAMICS: typing.ClassVar[RelativeDynamicsFactor]  # value = <_franky.RelativeDynamicsFactor object>
    @typing.overload
    def __init__(self) -> None:
        """
        Default constructor which initializes all values to 1.0.
        """
    @typing.overload
    def __init__(self, value: typing.SupportsFloat | typing.SupportsIndex) -> None:
        """
        Constructor which initializes all values to the given value.
        
        Args:
            value: The value to initialize all factors with. Must be in the range (0, 1].
        """
    @typing.overload
    def __init__(self, velocity: typing.SupportsFloat | typing.SupportsIndex, acceleration: typing.SupportsFloat | typing.SupportsIndex, jerk: typing.SupportsFloat | typing.SupportsIndex) -> None:
        """
        Args:
            velocity: The factor for the velocity. Must be in the range (0, 1].
            acceleration: The factor for the acceleration. Must be in the range (0, 1].
            jerk: The factor for the jerk. Must be in the range (0, 1].
        """
    def __mul__(self, arg0: RelativeDynamicsFactor | float) -> RelativeDynamicsFactor:
        ...
    @property
    def acceleration(self) -> float:
        """
        Acceleration factor.
        """
    @property
    def jerk(self) -> float:
        """
        Jerk factor.
        """
    @property
    def max_dynamics(self) -> bool:
        """
        Whether the maximum dynamics should be used.
        """
    @property
    def velocity(self) -> float:
        """
        Velocity factor.
        """
class RobotMode:
    """
    Describes the robot's current mode.
    
    Members:
    
      Other
    
      Idle
    
      Move
    
      Guiding
    
      Reflex
    
      UserStopped
    
      AutomaticErrorRecovery
    """
    AutomaticErrorRecovery: typing.ClassVar[RobotMode]  # value = <RobotMode.AutomaticErrorRecovery: 6>
    Guiding: typing.ClassVar[RobotMode]  # value = <RobotMode.Guiding: 3>
    Idle: typing.ClassVar[RobotMode]  # value = <RobotMode.Idle: 1>
    Move: typing.ClassVar[RobotMode]  # value = <RobotMode.Move: 2>
    Other: typing.ClassVar[RobotMode]  # value = <RobotMode.Other: 0>
    Reflex: typing.ClassVar[RobotMode]  # value = <RobotMode.Reflex: 4>
    UserStopped: typing.ClassVar[RobotMode]  # value = <RobotMode.UserStopped: 5>
    __members__: typing.ClassVar[dict[str, RobotMode]]  # value = {'Other': <RobotMode.Other: 0>, 'Idle': <RobotMode.Idle: 1>, 'Move': <RobotMode.Move: 2>, 'Guiding': <RobotMode.Guiding: 3>, 'Reflex': <RobotMode.Reflex: 4>, 'UserStopped': <RobotMode.UserStopped: 5>, 'AutomaticErrorRecovery': <RobotMode.AutomaticErrorRecovery: 6>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: typing.SupportsInt | typing.SupportsIndex) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: typing.SupportsInt | typing.SupportsIndex) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class RobotPose:
    """
    Cartesian pose of a robot.
    
    This class encapsulates the cartesian pose of a robot, which comprises the end effector pose and the
    elbow position.
    """
    def __getstate__(self) -> tuple[Affine, ElbowState | None]:
        ...
    @typing.overload
    def __init__(self, end_effector_pose: Affine, elbow_state: ElbowState | None = None) -> None:
        """
        Args:
            end_effector_pose: The pose of the end effector.
            elbow_state: The state of the elbow. Optional.
        """
    @typing.overload
    def __init__(self, arg0: RobotPose | Affine) -> None:
        ...
    def __mul__(self, arg0: Affine) -> RobotPose:
        ...
    def __repr__(self) -> str:
        ...
    def __rmul__(self, arg0: Affine) -> RobotPose:
        ...
    def __setstate__(self, arg0: tuple) -> None:
        ...
    def change_end_effector_frame(self, offset_world_frame: Affine) -> RobotPose:
        """
        Change the frame of the end effector by applying a transformation from the right side. This is
        equivalent to calling rightTransform(transform).
        
        Args:
            transform: The transform to apply.
        
        Returns:
            The robot pose with the new end effector frame.
        """
    def with_elbow_state(self, elbow_state: ElbowState | None) -> RobotPose:
        """
        Get the pose with a new elbow state.
        
        Args:
            elbow_state: The new elbow state.
        
        Returns:
            The pose with the new elbow state.
        """
    @property
    def elbow_state(self) -> ElbowState | None:
        """
        Get the elbow state.
        
        Returns:
            The elbow state.
        """
    @property
    def end_effector_pose(self) -> Affine:
        """
        Get the end effector pose.
        
        Returns:
            The end effector pose.
        """
class RobotState:
    """
    Full state of the robot
    
    This class contains all fields of franka::RobotState and some additional fields. Each additional
    field ends in "_est". Unlike franka::RobotState, all fields are converted to appropriate
    Eigen/franky types.
    """
    def __getstate__(self) -> tuple[Affine, Affine, Affine, Affine, Affine, Affine, float, typing.Annotated[numpy.typing.NDArray[numpy.float64], "[3, 3]"], typing.Annotated[numpy.typing.NDArray[numpy.float64], "[3, 1]"], float, typing.Annotated[numpy.typing.NDArray[numpy.float64], "[3, 3]"], typing.Annotated[numpy.typing.NDArray[numpy.float64], "[3, 1]"], float, typing.Annotated[numpy.typing.NDArray[numpy.float64], "[3, 3]"], typing.Annotated[numpy.typing.NDArray[numpy.float64], "[3, 1]"], ElbowState, ElbowState, ElbowState, float, float, typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 1]"], typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 1]"], typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 1]"], typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 1]"], typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 1]"], typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 1]"], typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 1]"], typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 1]"], typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 1]"], typing.Annotated[numpy.typing.NDArray[numpy.float64], "[6, 1]"], typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 1]"], typing.Annotated[numpy.typing.NDArray[numpy.float64], "[6, 1]"], typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 1]"], typing.Annotated[numpy.typing.NDArray[numpy.float64], "[6, 1]"], typing.Annotated[numpy.typing.NDArray[numpy.float64], "[6, 1]"], Twist, typing.Annotated[numpy.typing.NDArray[numpy.float64], "[3, 1]"], Affine, Twist, TwistAcceleration, typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 1]"], typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 1]"], Errors, Errors, float, RobotMode, Duration, typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 1]"] | None, typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 1]"] | None, typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 1]"] | None, Twist | None, TwistAcceleration | None, float | None, float | None]:
        ...
    def __setstate__(self, arg0: tuple) -> None:
        ...
    @property
    def EE_T_K(self) -> Affine:
        """
        :math:`^{EE}T_{K}` Stiffness frame pose in end effector frame.
        
        See also the stiffness frame K.
        """
    @property
    def F_T_EE(self) -> Affine:
        """
        :math:`^{F}T_{EE}` End effector frame pose in flange frame.
        
        See also:
            F_T_NE
        
        See also:
            NE_T_EE
        
        See also:
            Robot for an explanation of the F, NE and EE frames.
        """
    @property
    def F_T_NE(self) -> Affine:
        """
        :math:`^{F}T_{NE}` Nominal end effector frame pose in flange frame.
        
        See also:
            F_T_EE
        
        See also:
            NE_T_EE
        
        See also:
            Robot for an explanation of the F, NE and EE frames.
        """
    @property
    def F_x_Cee(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[3, 1]"]:
        """
        :math:`^{F}x_{C_{EE}}` Configured center of mass of the end effector load with respect to flange
        frame.
        """
    @property
    def F_x_Cload(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[3, 1]"]:
        """
        :math:`^{F}x_{C_{load}}` Configured center of mass of the external load with respect to flange
        frame.
        """
    @property
    def F_x_Ctotal(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[3, 1]"]:
        """
        :math:`^{F}x_{C_{total}}` Combined center of mass of the end effector load and the external load
        with respect to flange frame.
        """
    @property
    def I_ee(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[3, 3]"]:
        """
        :math:`I_{EE}` Configured rotational inertia matrix of the end effector load with respect to center
        of mass.
        """
    @property
    def I_load(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[3, 3]"]:
        """
        :math:`I_{load}` Configured rotational inertia matrix of the external load with respect to center of
        mass.
        """
    @property
    def I_total(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[3, 3]"]:
        """
        :math:`I_{total}` Combined rotational inertia matrix of the end effector load and the external load
        with respect to the center of mass.
        """
    @property
    def K_F_ext_hat_K(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[6, 1]"]:
        """
        :math:`^{K}F_{K,\\text{ext}}` Estimated external wrench (force, torque) acting on stiffness frame,
        expressed relative to the stiffness frame. Forces applied by the robot to the environment are
        positive, while forces applied by the environment on the robot are negative. Becomes
        :math:`[0,0,0,0,0,0]` when near or in a singularity. See also the stiffness frame K. Unit:
        :math:`[N,N,N,Nm,Nm,Nm]`.
        """
    @property
    def NE_T_EE(self) -> Affine:
        """
        :math:`^{NE}T_{EE}` End effector frame pose in nominal end effector frame.
        
        See also:
            Robot::setEE to change this frame.
        
        See also:
            F_T_EE
        
        See also:
            F_T_NE
        
        See also:
            Robot for an explanation of the F, NE and EE frames.
        """
    @property
    def O_F_ext_hat_K(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[6, 1]"]:
        """
        :math:`^OF_{K,\\text{ext}}` Estimated external wrench (force, torque) acting on stiffness frame,
        expressed relative to the the base frame. Forces applied by the robot to the environment are
        positive, while forces applied by the environment on the robot are negative. Becomes
        :math:`[0,0,0,0,0,0]` when near or in a singularity. See also the stiffness frame K. Unit:
        :math:`[N,N,N,Nm,Nm,Nm]`.
        """
    @property
    def O_T_EE(self) -> Affine:
        """
        :math:`^{O}T_{EE}` Measured end effector pose in the base frame.
        """
    @property
    def O_T_EE_c(self) -> Affine:
        """
        :math:`{^OT_{EE}}_{c}` Last commanded end effector pose of motion generation in the base frame.
        """
    @property
    def O_T_EE_d(self) -> Affine:
        """
        :math:`{^OT_{EE}}_{d}` Last desired end effector pose of motion generation in the base frame.
        """
    @property
    def O_dP_EE_c(self) -> Twist:
        """
        :math:`{^OdP_{EE}}_{c}` Last commanded end effector twist in the base frame.
        """
    @property
    def O_dP_EE_d(self) -> Twist:
        """
        :math:`{^OdP_{EE}}_{d}` Desired end effector twist in the base frame.
        Unit:
        :math:`[\\frac{m}{s},\\frac{m}{s},\\frac{m}{s},\\frac{rad}{s},\\frac{rad}{s},\\frac{rad}{s}]`.
        """
    @property
    def O_dP_EE_est(self) -> Twist | None:
        """
        Estimated end-effector twist (linear and angular velocity) expressed in the base frame. Computed by
        franky; not provided by franka firmware. Unit:
        :math:`[\\frac{m}{s},\\frac{m}{s},\\frac{m}{s},\\frac{rad}{s},\\frac{rad}{s},\\frac{rad}{s}]`.
        """
    @property
    def O_ddP_EE_c(self) -> TwistAcceleration:
        """
        :math:`{^OddP_{EE}}_{c}` Last commanded end effector acceleration in the base frame.
        Unit:
        :math:`[\\frac{m}{s^2},\\frac{m}{s^2},\\frac{m}{s^2},\\frac{rad}{s^2},\\frac{rad}{s^2},\\frac{rad}{s^2}]`.
        """
    @property
    def O_ddP_EE_est(self) -> TwistAcceleration | None:
        """
        Estimated end-effector spatial acceleration (linear and angular acceleration) expressed in the base
        frame. Computed by franky; not provided by franka firmware. Unit:
        :math:`[\\frac{m}{s^2},\\frac{m}{s^2},\\frac{m}{s^2},\\frac{rad}{s^2},\\frac{rad}{s^2},\\frac{rad}{s^2}]`.
        """
    @property
    def O_ddP_O(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[3, 1]"]:
        """
        :math:`{^OddP}_O` Linear component of the acceleration of the robot's base, expressed in frame
        parallel to the the base frame, i.e. the base's translational acceleration. If the base is resting
        this shows the direction of the gravity vector. It is hardcoded for now to `{0, 0, -9.81}`.
        """
    @property
    def cartesian_collision(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[6, 1]"]:
        """
        Indicates which contact level is activated in which Cartesian dimension :math:`(x,y,z,R,P,Y)`. After
        contact disappears, the value stays the same until a reset command is sent.
        
        See also:
            Robot::setCollisionBehavior for setting sensitivity values.
        
        See also:
            Robot::automaticErrorRecovery for performing a reset after a collision.
        """
    @property
    def cartesian_contact(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[6, 1]"]:
        """
        Indicates which contact level is activated in which Cartesian dimension :math:`(x,y,z,R,P,Y)`. After
        contact disappears, the value turns to zero.
        
        See also:
            Robot::setCollisionBehavior for setting sensitivity values.
        """
    @property
    def control_command_success_rate(self) -> float:
        """
        Percentage of the last 100 control commands that were successfully received by the robot.
        
        Shows a value of zero if no control or motion generator loop is currently running.
        
        Range: :math:`[0, 1]`.
        """
    @property
    def current_errors(self) -> Errors:
        """
        Current error state.
        """
    @property
    def ddelbow_c(self) -> float:
        """
        Commanded elbow acceleration of the 3rd joint in :math:`\\frac{rad}{s^2}`
        """
    @property
    def ddelbow_est(self) -> float | None:
        """
        Estimated elbow acceleration (acceleration of the third joint), computed by franky. Not provided by
        franka firmware. Unit: :math:`[\\frac{rad}{s^2}]`.
        """
    @property
    def ddq_d(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 1]"]:
        """
        :math:`\\ddot{q}_d` Desired joint acceleration. Unit: :math:`[\\frac{rad}{s^2}]`
        """
    @property
    def ddq_est(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 1]"] | None:
        """
        Estimated joint acceleration computed by franky. This value does not come from the franka firmware.
        Unit: :math:`[\\frac{rad}{s^2}]`.
        """
    @property
    def delbow_c(self) -> float:
        """
        Commanded velocity of the 3rd joint in :math:`\\frac{rad}{s}`
        """
    @property
    def delbow_est(self) -> float | None:
        """
        Estimated elbow velocity (velocity of the third joint), computed by franky. Not provided by franka
        firmware.
        Unit: :math:`[\\frac{rad}{s}]`.
        """
    @property
    def dq(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 1]"]:
        """
        :math:`\\dot{q}` Measured joint velocity. Unit: :math:`[\\frac{rad}{s}]`
        """
    @property
    def dq_d(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 1]"]:
        """
        :math:`\\dot{q}_d` Desired joint velocity. Unit: :math:`[\\frac{rad}{s}]`
        """
    @property
    def dq_est(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 1]"] | None:
        """
        Estimated joint velocity computed by franky. This value does not come from the franka firmware.
        Unit: :math:`[\\frac{rad}{s}]`.
        """
    @property
    def dtau_J(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 1]"]:
        """
        :math:`\\dot{\\tau_{J}}` Derivative of measured link-side joint torque sensor signals. Unit:
        :math:`[\\frac{Nm}{s}]`
        """
    @property
    def dtheta(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 1]"]:
        """
        :math:`\\dot{\\theta}` Motor velocity. Unit: :math:`[\\frac{rad}{s}]`
        """
    @property
    def elbow(self) -> ElbowState:
        """
        Elbow configuration.
        """
    @property
    def elbow_c(self) -> ElbowState:
        """
        Commanded elbow configuration.
        """
    @property
    def elbow_d(self) -> ElbowState:
        """
        Desired elbow configuration.
        """
    @property
    def joint_collision(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 1]"]:
        """
        Indicates which contact level is activated in which joint. After contact disappears, the value stays
        the same until a reset command is sent.
        
        See also:
            Robot::setCollisionBehavior for setting sensitivity values.
        
        See also:
            Robot::automaticErrorRecovery for performing a reset after a collision.
        """
    @property
    def joint_contact(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 1]"]:
        """
        Indicates which contact level is activated in which joint. After contact disappears, value turns to
        zero.
        
        See also:
            Robot::setCollisionBehavior for setting sensitivity values.
        """
    @property
    def last_motion_errors(self) -> Errors:
        """
        Contains the errors that aborted the previous motion.
        """
    @property
    def m_ee(self) -> float:
        """
        :math:`m_{EE}` Configured mass of the end effector.
        """
    @property
    def m_load(self) -> float:
        """
        :math:`m_{load}` Configured mass of the external load.
        """
    @property
    def m_total(self) -> float:
        """
        :math:`m_{total}` Sum of the mass of the end effector and the external load.
        """
    @property
    def q(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 1]"]:
        """
        :math:`q` Measured joint position. Unit: :math:`[rad]`
        """
    @property
    def q_d(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 1]"]:
        """
        :math:`q_d` Desired joint position. Unit: :math:`[rad]`
        """
    @property
    def q_est(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 1]"] | None:
        """
        Estimated joint position computed by franky. This value does not come from the franka firmware.
        Unit: :math:`[rad]`.
        """
    @property
    def robot_mode(self) -> RobotMode:
        """
        Current robot mode.
        """
    @property
    def tau_J(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 1]"]:
        """
        :math:`\\tau_{J}` Measured link-side joint torque sensor signals. Unit: :math:`[Nm]`
        """
    @property
    def tau_J_d(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 1]"]:
        """
        :math:`{\\tau_J}_d` Desired link-side joint torque sensor signals without gravity. Unit: :math:`[Nm]`
        """
    @property
    def tau_ext_hat_filtered(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 1]"]:
        """
        :math:`\\hat{\\tau}_{\\text{ext}}` Low-pass filtered torques generated by external forces on the
        joints. It does not include configured end-effector and load nor the mass and dynamics of the robot.
        tau_ext_hat_filtered is the error between tau_J and the expected torques given by the robot model.
        Unit: :math:`[Nm]`.
        """
    @property
    def theta(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 1]"]:
        """
        :math:`\\theta` Motor position. Unit: :math:`[rad]`
        """
    @property
    def time(self) -> Duration:
        """
        Strictly monotonically increasing timestamp since robot start.
        
        Inside of control loops, the time_step parameter of the control loop callbacks can be used instead.
        """
class RobotVelocity:
    """
    Cartesian velocity of a robot.
    
    This class encapsulates the cartesian velocity of a robot, which comprises the end effector twist
    and the elbow velocity.
    """
    def __getstate__(self) -> tuple[Twist, float | None]:
        ...
    @typing.overload
    def __init__(self, end_effector_twist: Twist, elbow_velocity: typing.SupportsFloat | typing.SupportsIndex | None = None) -> None:
        """
        Args:
            end_effector_twist: The twist of the end effector.
            elbow_velocity: The velocity of the elbow (optional).
        """
    @typing.overload
    def __init__(self, arg0: RobotVelocity | Twist) -> None:
        ...
    def __repr__(self) -> str:
        ...
    @typing.overload
    def __rmul__(self, arg0: Affine) -> RobotVelocity:
        ...
    @typing.overload
    def __rmul__(self, arg0: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[4, 1]"]) -> RobotVelocity:
        ...
    def __setstate__(self, arg0: tuple) -> None:
        ...
    def change_end_effector_frame(self, offset_world_frame: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[3, 1]"]) -> RobotVelocity:
        """
        Change the end-effector frame by adding the given offset to the current end-effector frame. Note
        that the offset must be given in world coordinates.
        
        Args:
            offset_world_frame: The offset to add to the current end-effector frame.
        
        Returns:
            The velocity of the new end-effector frame.
        """
    def with_elbow_velocity(self, elbow_velocity: typing.SupportsFloat | typing.SupportsIndex | None) -> RobotVelocity:
        """
        Get the velocity with a new elbow velocity.
        
        Args:
            elbow_velocity: The new elbow velocity.
        
        Returns:
            The velocity with the new elbow velocity.
        """
    @property
    def elbow_velocity(self) -> float | None:
        """
        Get the elbow velocity.
        
        Returns:
            The elbow velocity.
        """
    @property
    def end_effector_twist(self) -> Twist:
        """
        Get the end effector twist.
        
        Returns:
            The end effector twist.
        """
class SimpleTorqueMotion(BaseTorqueMotion):
    """
    Direct joint torque control with a signal watchdog.
    
    This motion applies the joint torques it is given, without any feedback law on top. Until the first
    torque signal arrives, it applies SimpleTorqueParams::initial_torque. New torques are published with
    setTorque from a user thread, analogous to how the references of the impedance motions are updated,
    and are picked up by the control loop in the next cycle.
    
    As the robot is not commanded by any controller in between torque signals, the motion terminates
    with a TorqueSignalTimeoutException if no new torque arrives within
    SimpleTorqueParams::signal_timeout (50ms by default). Hence, the torque has to be updated regularly,
    even if it does not change.
    
    Note that the commanded torques are still subject to the torque rate limit
    (TorqueSafetyParams::max_delta_tau), so large steps are ramped in over multiple cycles.
    """
    def __init__(self, initial_torque: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[7, 1]"] | None = None, signal_timeout: typing.SupportsFloat | typing.SupportsIndex | None = 0.05, compensate_coriolis: bool = False, max_delta_tau: typing.SupportsFloat | typing.SupportsIndex = 1.0, lower_joint_limits: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[7, 1]"] | None = None, upper_joint_limits: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[7, 1]"] | None = None, joint_limit_activation_distance: typing.SupportsFloat | typing.SupportsIndex = 0.1, joint_limit_stiffness: typing.SupportsFloat | typing.SupportsIndex = 4.0, joint_limit_damping: typing.SupportsFloat | typing.SupportsIndex = 1.0, joint_limit_max_torque: typing.SupportsFloat | typing.SupportsIndex = 5.0, friction: FrictionCompensationParams | None = None) -> None:
        """
        Construct a direct joint torque controller.
        
        The motion applies the joint torques it is given, without any feedback law on top. Until
        the first call to set_torque, it applies initial_torque (zero by default). Afterwards, it
        applies the last torque published with set_torque, analogous to how the references of the
        impedance motions are updated.
        
        As the robot is not commanded by any controller in between torque signals, the motion
        terminates with a TorqueSignalTimeoutException if no new torque arrives within
        signal_timeout seconds (0.05 by default, None to disable). Hence, set_torque has to be
        called regularly, even if the torque does not change.
        
        Note that the commanded torques are still subject to the torque rate limit max_delta_tau,
        so large steps are ramped in over multiple cycles.
        """
    def get_torque(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 1]"]:
        """
        Get a copy of the last published torque [Nm], or the initial torque if no torque has been published
        yet.
        """
    def set_torque(self, torque: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[7, 1]"]) -> None:
        """
        Set the torque applied by the motion [Nm].
        
        The torque is validated and picked up by the control loop in the next cycle. It also resets the
        watchdog, so this function has to be called at least every SimpleTorqueParams::signal_timeout
        seconds while the motion is running.
        
        Args:
            torque: The new joint torques [Nm].
        """
    @property
    def params(self) -> SimpleTorqueParams:
        """
        The parameters of the motion.
        """
class SimpleTorqueParams:
    """
    Parameters for SimpleTorqueMotion.
    """
    def __init__(self) -> None:
        ...
    @property
    def compensate_coriolis(self) -> bool:
        """
        Compensate Coriolis forces using the robot model.
        """
    @compensate_coriolis.setter
    def compensate_coriolis(self, arg0: bool) -> None:
        ...
    @property
    def friction(self) -> FrictionCompensationParams:
        """
        Joint friction compensation settings.
        """
    @friction.setter
    def friction(self, arg0: FrictionCompensationParams) -> None:
        ...
    @property
    def initial_torque(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 1]"]:
        """
        Torque applied until the first torque signal arrives [Nm].
        """
    @initial_torque.setter
    def initial_torque(self, arg0: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[7, 1]"]) -> None:
        ...
    @property
    def safety(self) -> TorqueSafetyParams:
        """
        Shared torque safety limits and soft joint-limit repulsion settings.
        """
    @safety.setter
    def safety(self, arg0: TorqueSafetyParams) -> None:
        ...
    @property
    def signal_timeout(self) -> float | None:
        """
        Maximum duration [s] the motion tolerates without receiving a new torque signal before it terminates
        with a TorqueSignalTimeoutException. The watchdog is armed when the motion starts, so the initial
        torque is only held for this duration as well. Set to nullopt to disable the watchdog and hold the
        last commanded torque indefinitely.
        """
    @signal_timeout.setter
    def signal_timeout(self, arg0: typing.SupportsFloat | typing.SupportsIndex | None) -> None:
        ...
class TorqueReaction:
    """
    A reaction that can be attached to a motion.
    
    This class defines a reaction in a motion, which can be used to change the motion based on the robot
    state. Reactions consist of a condition and a motion that replaces the current motion immediately if
    the condition is met.
    """
    def __init__(self, condition: Condition | bool, motion: BaseTorqueMotion | None = None) -> None:
        """
        Args:
            condition: The condition that must be met for the reaction to be executed.
            new_motion: The motion that is executed if the condition is met.
        """
    def register_callback(self, callback: collections.abc.Callable[[RobotState, Duration, Duration], None]) -> None:
        """
        Register a callback that is called when the condition of this reaction is met.
        
        Args:
            callback: The callback to register. Callbacks are called with the robot state, the relative time
                      [s] and the absolute time [s].
        """
class TorqueSafetyParams:
    """
    Shared torque safety limits and soft joint-limit repulsion settings for torque-control motions.
    """
    def __init__(self) -> None:
        ...
    @property
    def joint_limit_activation_distance(self) -> float:
        """
        Activation distance from a limit in [rad].
        """
    @joint_limit_activation_distance.setter
    def joint_limit_activation_distance(self, arg0: typing.SupportsFloat | typing.SupportsIndex) -> None:
        ...
    @property
    def joint_limit_damping(self) -> float:
        """
        Additional damping when moving into a limit in [Nms/rad].
        """
    @joint_limit_damping.setter
    def joint_limit_damping(self, arg0: typing.SupportsFloat | typing.SupportsIndex) -> None:
        ...
    @property
    def joint_limit_max_torque(self) -> float:
        """
        Absolute torque clamp for the repulsion term in [Nm].
        """
    @joint_limit_max_torque.setter
    def joint_limit_max_torque(self, arg0: typing.SupportsFloat | typing.SupportsIndex) -> None:
        ...
    @property
    def joint_limit_stiffness(self) -> float:
        """
        Base repulsion gain in [Nm].
        """
    @joint_limit_stiffness.setter
    def joint_limit_stiffness(self, arg0: typing.SupportsFloat | typing.SupportsIndex) -> None:
        ...
    @property
    def lower_joint_limits(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 1]"] | None:
        """
        Lower soft joint limits in [rad]. Joint-limit repulsion is active when both limits are set.
        """
    @lower_joint_limits.setter
    def lower_joint_limits(self, arg0: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[7, 1]"] | None) -> None:
        ...
    @property
    def max_delta_tau(self) -> float:
        """
        Maximum allowed torque step per cycle in [Nm].
        """
    @max_delta_tau.setter
    def max_delta_tau(self, arg0: typing.SupportsFloat | typing.SupportsIndex) -> None:
        ...
    @property
    def upper_joint_limits(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 1]"] | None:
        """
        Upper soft joint limits in [rad]. Joint-limit repulsion is active when both limits are set.
        """
    @upper_joint_limits.setter
    def upper_joint_limits(self, arg0: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[7, 1]"] | None) -> None:
        ...
class TorqueSignalTimeoutException(builtins.Exception):
    """
    Thrown when a SimpleTorqueMotion does not receive a new torque signal in time.
    """
class TorqueStopMotion(BaseTorqueMotion):
    """
    Graceful stop for torque-control (impedance) motions.
    
    Torque motions never signal MotionFinished on their own, and franka::Robot::stop() preempts the
    control loop with a franka::ControlException rather than ramping down. This motion ramps the last
    commanded torque into a damping-only law and then returns franka::MotionFinished.
    """
    def __init__(self, damping: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[7, 1]"] | None = None, ramp_duration: typing.SupportsFloat | typing.SupportsIndex = 0.2, velocity_epsilon: typing.SupportsFloat | typing.SupportsIndex = 0.02, max_duration: typing.SupportsFloat | typing.SupportsIndex = 2.0, compensate_coriolis: bool = True, max_delta_tau: typing.SupportsFloat | typing.SupportsIndex = 1.0) -> None:
        """
        Graceful stop for torque-control (impedance) motions.
        
        Torque motions never signal MotionFinished on their own, and Robot.stop() preempts the
        control loop with a ControlException rather than ramping down. Enqueue this motion (or
        return it from a TorqueReaction) to end a torque loop cleanly: it blends the last
        commanded torque into a zero-stiffness joint-damping law, brings the arm to rest, then
        finishes. The motion also finishes after max_duration regardless of velocity, so a
        sustained external push cannot make it hang.
        """
class TorqueStopParams:
    """
    Parameters for the torque-control stop motion (StopMotion<franka::Torques>).
    """
    def __init__(self) -> None:
        ...
    @property
    def compensate_coriolis(self) -> bool:
        """
        Compensate Coriolis forces.
        """
    @compensate_coriolis.setter
    def compensate_coriolis(self, arg0: bool) -> None:
        ...
    @property
    def damping(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 1]"]:
        """
        Pure joint damping [Nms/rad] used to bring the arm to rest.
        """
    @damping.setter
    def damping(self, arg0: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[7, 1]"]) -> None:
        ...
    @property
    def max_delta_tau(self) -> float:
        """
        Per-tick torque-rate limit [Nm] for smoothness.
        """
    @max_delta_tau.setter
    def max_delta_tau(self, arg0: typing.SupportsFloat | typing.SupportsIndex) -> None:
        ...
    @property
    def max_duration(self) -> float:
        """
        Maximum duration [s] before the motion finishes regardless of velocity.
        """
    @max_duration.setter
    def max_duration(self, arg0: typing.SupportsFloat | typing.SupportsIndex) -> None:
        ...
    @property
    def ramp_duration(self) -> float:
        """
        Duration [s] over which the inherited command is ramped into the damping-only law. Set to 0 to
        switch immediately.
        """
    @ramp_duration.setter
    def ramp_duration(self, arg0: typing.SupportsFloat | typing.SupportsIndex) -> None:
        ...
    @property
    def velocity_epsilon(self) -> float:
        """
        Finish once every joint speed is below this [rad/s] (after the ramp completes).
        """
    @velocity_epsilon.setter
    def velocity_epsilon(self, arg0: typing.SupportsFloat | typing.SupportsIndex) -> None:
        ...
class Torques:
    """
    Stores joint-level torque commands without gravity and friction.
    """
    def __getstate__(self) -> tuple[typing.Annotated[list[float], "FixedSize(7)"], bool]:
        ...
    def __setstate__(self, arg0: tuple) -> None:
        ...
    @property
    def motion_finished(self) -> bool:
        ...
    @property
    def tau_J(self) -> typing.Annotated[list[float], "FixedSize(7)"]:
        """
        Desired torques in [Nm].
        """
class Twist:
    """
    Twist of a frame.
    """
    def __getstate__(self) -> tuple[typing.Annotated[numpy.typing.NDArray[numpy.float64], "[3, 1]"], typing.Annotated[numpy.typing.NDArray[numpy.float64], "[3, 1]"]]:
        ...
    @typing.overload
    def __init__(self, linear_velocity: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[3, 1]"] | None = None, angular_velocity: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[3, 1]"] | None = None) -> None:
        """
        Args:
            linear_velocity: The linear velocity in [m/s].
            angular_velocity: The angular velocity in [rad/s].
        """
    @typing.overload
    def __init__(self, arg0: Twist) -> None:
        ...
    def __repr__(self) -> str:
        ...
    @typing.overload
    def __rmul__(self, arg0: Affine) -> Twist:
        ...
    @typing.overload
    def __rmul__(self, arg0: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[4, 1]"]) -> Twist:
        ...
    def __setstate__(self, arg0: tuple) -> None:
        ...
    def propagate_through_link(self, link_translation: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[3, 1]"]) -> Twist:
        """
        Propagate the twist through a link with the given translation.
        
        Hence, suppose this twist is the twist of a frame A, then this function computes the twist of a
        frame B that is rigidly attached to frame A by a link with the given translation: B = A + T, where T
        is the translation.
        
        Args:
            link_translation: The translation of the link. Must be in the same reference frame as this
                              twist.
        
        Returns:
            The twist propagated through the link.
        """
    @typing.overload
    def transform_with(self, affine: Affine) -> Twist:
        """
        Transform the frame of the twist by applying the given affine transform.
        
        Args:
            transformation: The transformation to apply.
        
        Returns:
            The twist after the transformation.
        """
    @typing.overload
    def transform_with(self, quaternion: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[4, 1]"]) -> Twist:
        """
        Transform the frame of the twist by applying the given rotation.
        
        Args:
            rotation: The rotation to apply.
        
        Returns:
            The twist after the transformation.
        """
    @property
    def angular(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[3, 1]"]:
        """
        Get the angular velocity.
        
        Returns:
            The angular velocity [rad/s].
        """
    @property
    def linear(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[3, 1]"]:
        """
        Get the linear velocity.
        
        Returns:
            The linear velocity [m/s].
        """
class TwistAcceleration:
    """
    Acceleration of a frame (2nd time derivative of a pose, consisting of a linear and an angular
    acceleration).
    """
    def __getstate__(self) -> tuple[typing.Annotated[numpy.typing.NDArray[numpy.float64], "[3, 1]"], typing.Annotated[numpy.typing.NDArray[numpy.float64], "[3, 1]"]]:
        ...
    @typing.overload
    def __init__(self, linear_acceleration: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[3, 1]"] | None = None, angular_acceleration: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[3, 1]"] | None = None) -> None:
        """
        Args:
            linear_acceleration: The linear acceleration in [m/s^2].
            angular_acceleration: The angular acceleration in [rad/s^2].
        """
    @typing.overload
    def __init__(self, arg0: TwistAcceleration) -> None:
        ...
    def __repr__(self) -> str:
        ...
    @typing.overload
    def __rmul__(self, arg0: Affine) -> TwistAcceleration:
        ...
    @typing.overload
    def __rmul__(self, arg0: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[4, 1]"]) -> TwistAcceleration:
        ...
    def __setstate__(self, arg0: tuple) -> None:
        ...
    def propagate_through_link(self, link_translation: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[3, 1]"], base_angular_velocity: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[3, 1]"]) -> TwistAcceleration:
        """
        Propagate the twist acceleration through a link with the given translation. Hence, suppose this
        twist acceleration is the twist acceleration of a frame A, then this function computes the twist
        acceleration of a frame B that is rigidly attached to frame A by a link with the given translation:
        B = A + T, where T is the translation.
        
        Args:
            link_translation: The translation of the link (A to B). Must be in the same reference frame as
                              this twist acceleration.
            base_angular_velocity: Angular velocity of the base frame (A) [rad/s]. Must be in the same
                                   reference frame as this twist acceleration.
        
        Returns:
            The twist acceleration propagated through the link.
        """
    @typing.overload
    def transform_with(self, affine: Affine) -> TwistAcceleration:
        """
        Transform the frame of the twist acceleration by applying the given affine transform.
        
        Args:
            transformation: The transformation to apply.
        
        Returns:
            The twist acceleration after the transformation.
        """
    @typing.overload
    def transform_with(self, quaternion: typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[4, 1]"]) -> TwistAcceleration:
        """
        Transform the frame of the twist acceleration by applying the given rotation.
        
        Args:
            rotation: The rotation to apply.
        
        Returns:
            The twist acceleration after the transformation.
        """
    @property
    def angular(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[3, 1]"]:
        """
        Get the angular acceleration.
        
        Returns:
            The angular acceleration [rad/s^2].
        """
    @property
    def linear(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[3, 1]"]:
        """
        Get the linear acceleration.
        
        Returns:
            The linear acceleration [m/s^2].
        """
class VectorDynamicsLimit:
    """
    A template class representing a dynamics limit with a maximum value.
    
    This class provides functionality to store and manage a dynamic limit, including setting and getting
    the value of the limit while ensuring that it cannot be written while the robot is in control.
    
    Template Args:
        LimitType: The type of the limit value (e.g., double, int).
    """
    def __repr__(self) -> str:
        ...
    def get(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 1]"]:
        """
        Get the current value of the limit.
        
        Retrieves the current value stored in this limit.
        
        Returns:
            The current value of the limit.
        """
    def set(self, value: typing.Annotated[collections.abc.Sequence[typing.SupportsFloat | typing.SupportsIndex], "FixedSize(7)"] | typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[7, 1]"]) -> None:
        """
        Set a new value for the limit.
        
        Sets the value of the limit, but only if the robot is not in control. Throws a runtime_error if the
        condition for writing to the limit is not met.
        
        Args:
            value: The new value to set for the limit.
        
        Raises:
            std::runtime_error: if the limit cannot be set due to the robot being in control.
        """
    @property
    def desc(self) -> str:
        """
        Description of this limit.
        
        This string provides a human-readable description of the limit, such as "joint velocity" or "maximum
        load".
        """
    @property
    def max(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 1]"]:
        """
        The maximum value this limit can take as defined by Franka.
        
        This value represents the maximum boundary for the limit, beyond which the value cannot be set.
        """
class _RobotInternal:
    """
    A class representing a Franka robot.
    
    This class extends the franka::Robot class and adds additional functionality to it.
    """
    control_rate: typing.ClassVar[float] = 0.001
    degrees_of_freedom: typing.ClassVar[int] = 7
    def __init__(self, fci_hostname: str, relative_dynamics_factor: RelativeDynamicsFactor | float = 1.0, default_torque_threshold: typing.SupportsFloat | typing.SupportsIndex = 20.0, default_force_threshold: typing.SupportsFloat | typing.SupportsIndex = 30.0, controller_mode: ControllerMode = ..., realtime_config: RealtimeConfig = ..., kalman_q_process_var: typing.SupportsFloat | typing.SupportsIndex = 0.0001, kalman_dq_process_var: typing.SupportsFloat | typing.SupportsIndex = 0.001, kalman_ddq_process_var: typing.SupportsFloat | typing.SupportsIndex = 0.1, kalman_control_process_var: typing.SupportsFloat | typing.SupportsIndex = 1.0, kalman_q_obs_var: typing.SupportsFloat | typing.SupportsIndex = 0.01, kalman_dq_obs_var: typing.SupportsFloat | typing.SupportsIndex = 0.1, kalman_q_d_obs_var: typing.SupportsFloat | typing.SupportsIndex = 0.0001, kalman_dq_d_obs_var: typing.SupportsFloat | typing.SupportsIndex = 0.0001, kalman_ddq_d_obs_var: typing.SupportsFloat | typing.SupportsIndex = 0.0001, kalman_control_adaptation_rate: typing.SupportsFloat | typing.SupportsIndex = 0.1) -> None:
        """
        Connect to a Franka robot.
        
        Args:
            fci_hostname: The hostname or IP address of the robot.
            relative_dynamics_factor: Global relative dynamics factor. The maximum velocity,
                                      acceleration, and jerk of the robot are scaled by this factor.
            default_torque_threshold: Default torque threshold for the collision behavior [Nm].
            default_force_threshold: Default force threshold for the collision behavior [N].
            controller_mode: Default controller mode. See the libfranka documentation for details.
            realtime_config: Realtime configuration. If set to RealtimeConfig.Enforce, the connection
                             fails if no realtime kernel is available.
            kalman_q_process_var, ...: Noise variances of the Kalman filter franky uses to estimate the
                                       robot state (the ``*_est`` fields of RobotState).
            kalman_control_adaptation_rate: Rate of adaptation of the estimated robot state to the
                                            desired robot state.
        """
    def join_motion(self, timeout: typing.SupportsFloat | typing.SupportsIndex | None = None) -> bool:
        """
        Wait for the current motion to finish and throw any exception that occurred during the motion.
        
        Args:
            timeout: Maximum time to wait [s]. If None, waits indefinitely.
        
        Returns:
            True if the motion finished before the timeout expired, False otherwise.
        """
    @typing.overload
    def move(self, motion: BaseCartesianPoseMotion, asynchronous: bool = False, limit_rate: bool = False, cutoff_frequency: typing.SupportsFloat | typing.SupportsIndex = 100.0) -> None:
        """
        Execute the given motion.
        
        If a motion is already running, the new motion is queued and takes over seamlessly. The type of
        control signal (e.g. joint positions, cartesian velocities, torques, ...) must not change while
        the robot is in motion.
        
        Args:
            motion: The motion to execute.
            asynchronous: Whether to return immediately instead of waiting for the motion to finish.
                          Asynchronous motions can be joined with join_motion.
            limit_rate: True if Franka's rate limiting should be activated. False by default.
                        This could distort your motion!
            cutoff_frequency: Cutoff frequency for a first order low-pass filter applied on
                              the user commanded signal. Set to franka.kMaxCutoffFrequency to disable.
        """
    @typing.overload
    def move(self, motion: BaseCartesianVelocityMotion, asynchronous: bool = False, limit_rate: bool = False, cutoff_frequency: typing.SupportsFloat | typing.SupportsIndex = 100.0) -> None:
        """
        Execute the given motion.
        
        If a motion is already running, the new motion is queued and takes over seamlessly. The type of
        control signal (e.g. joint positions, cartesian velocities, torques, ...) must not change while
        the robot is in motion.
        
        Args:
            motion: The motion to execute.
            asynchronous: Whether to return immediately instead of waiting for the motion to finish.
                          Asynchronous motions can be joined with join_motion.
            limit_rate: True if Franka's rate limiting should be activated. False by default.
                        This could distort your motion!
            cutoff_frequency: Cutoff frequency for a first order low-pass filter applied on
                              the user commanded signal. Set to franka.kMaxCutoffFrequency to disable.
        """
    @typing.overload
    def move(self, motion: BaseJointPositionMotion, asynchronous: bool = False, limit_rate: bool = False, cutoff_frequency: typing.SupportsFloat | typing.SupportsIndex = 100.0) -> None:
        """
        Execute the given motion.
        
        If a motion is already running, the new motion is queued and takes over seamlessly. The type of
        control signal (e.g. joint positions, cartesian velocities, torques, ...) must not change while
        the robot is in motion.
        
        Args:
            motion: The motion to execute.
            asynchronous: Whether to return immediately instead of waiting for the motion to finish.
                          Asynchronous motions can be joined with join_motion.
            limit_rate: True if Franka's rate limiting should be activated. False by default.
                        This could distort your motion!
            cutoff_frequency: Cutoff frequency for a first order low-pass filter applied on
                              the user commanded signal. Set to franka.kMaxCutoffFrequency to disable.
        """
    @typing.overload
    def move(self, motion: BaseJointVelocityMotion, asynchronous: bool = False, limit_rate: bool = False, cutoff_frequency: typing.SupportsFloat | typing.SupportsIndex = 100.0) -> None:
        """
        Execute the given motion.
        
        If a motion is already running, the new motion is queued and takes over seamlessly. The type of
        control signal (e.g. joint positions, cartesian velocities, torques, ...) must not change while
        the robot is in motion.
        
        Args:
            motion: The motion to execute.
            asynchronous: Whether to return immediately instead of waiting for the motion to finish.
                          Asynchronous motions can be joined with join_motion.
            limit_rate: True if Franka's rate limiting should be activated. False by default.
                        This could distort your motion!
            cutoff_frequency: Cutoff frequency for a first order low-pass filter applied on
                              the user commanded signal. Set to franka.kMaxCutoffFrequency to disable.
        """
    @typing.overload
    def move(self, motion: BaseTorqueMotion, asynchronous: bool = False, limit_rate: bool = False, cutoff_frequency: typing.SupportsFloat | typing.SupportsIndex = 100.0) -> None:
        """
        Execute the given motion.
        
        If a motion is already running, the new motion is queued and takes over seamlessly. The type of
        control signal (e.g. joint positions, cartesian velocities, torques, ...) must not change while
        the robot is in motion.
        
        Args:
            motion: The motion to execute.
            asynchronous: Whether to return immediately instead of waiting for the motion to finish.
                          Asynchronous motions can be joined with join_motion.
            limit_rate: True if Franka's rate limiting should be activated. False by default.
                        This could distort your motion!
            cutoff_frequency: Cutoff frequency for a first order low-pass filter applied on
                              the user commanded signal. Set to franka.kMaxCutoffFrequency to disable.
        """
    def poll_motion(self) -> bool:
        """
        Check whether the robot is still in motion. This function is non-blocking and returns immediately.
        Throw any exceptions that occurred during the motion.
        
        Returns:
            Whether the robot is still in motion.
        """
    def recover_from_errors(self) -> bool:
        """
        Calls the automatic error recovery of the robot and returns whether the recovery was successful.
        
        Returns:
            Whether the recovery was successful.
        """
    def set_cartesian_impedance(self, K_x: typing.Annotated[collections.abc.Sequence[typing.SupportsFloat | typing.SupportsIndex], "FixedSize(6)"]) -> None:
        """
        Sets the Cartesian stiffness/compliance (for x, y, z, roll, pitch, yaw) in the internal controller.
        
        The values set using Robot::setCartesianImpedance are used in the direction of the stiffness frame,
        which can be set with Robot::setK.
        
        Inputs received by the torque controller are not affected by this setting.
        
        Args:
            K_x: Cartesian impedance values :math:`K_x=(K_{x_{x,y,z}} \\in [10,3000] \\frac{N}{m},
                      K_{x_{R,P,Y}} \\in [1,300] \\frac{Nm}{rad})`
        
        Raises:
            CommandException: if the Control reports an error.
            NetworkException: if the connection is lost, e.g. after a timeout.
        """
    @typing.overload
    def set_collision_behavior(self, torque_thresholds: typing.SupportsFloat | typing.SupportsIndex | typing.Annotated[collections.abc.Sequence[typing.SupportsFloat | typing.SupportsIndex], "FixedSize(7)"] | typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[7, 1]"], force_thresholds: typing.SupportsFloat | typing.SupportsIndex | typing.Annotated[collections.abc.Sequence[typing.SupportsFloat | typing.SupportsIndex], "FixedSize(6)"] | typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[6, 1]"]) -> None:
        """
        Set the collision behavior of the robot.
        
        Args:
            torque_threshold: The torque threshold for the collision behavior in Nm.
            force_threshold: The force threshold for the collision behavior in N.
        """
    @typing.overload
    def set_collision_behavior(self, lower_torque_threshold: typing.SupportsFloat | typing.SupportsIndex | typing.Annotated[collections.abc.Sequence[typing.SupportsFloat | typing.SupportsIndex], "FixedSize(7)"] | typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[7, 1]"], upper_torque_threshold: typing.SupportsFloat | typing.SupportsIndex | typing.Annotated[collections.abc.Sequence[typing.SupportsFloat | typing.SupportsIndex], "FixedSize(7)"] | typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[7, 1]"], lower_force_threshold: typing.SupportsFloat | typing.SupportsIndex | typing.Annotated[collections.abc.Sequence[typing.SupportsFloat | typing.SupportsIndex], "FixedSize(6)"] | typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[6, 1]"], upper_force_threshold: typing.SupportsFloat | typing.SupportsIndex | typing.Annotated[collections.abc.Sequence[typing.SupportsFloat | typing.SupportsIndex], "FixedSize(6)"] | typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[6, 1]"]) -> None:
        """
        Set the collision behavior of the robot.
        
        Args:
            lower_torque_threshold: The lower torque threshold for the collision behavior in Nm.
            upper_torque_threshold: The upper torque threshold for the collision behavior in Nm.
            lower_force_threshold: The lower force threshold for the collision behavior in N.
            upper_force_threshold: The upper force threshold for the collision behavior in N.
        """
    @typing.overload
    def set_collision_behavior(self, lower_torque_threshold_acceleration: typing.SupportsFloat | typing.SupportsIndex | typing.Annotated[collections.abc.Sequence[typing.SupportsFloat | typing.SupportsIndex], "FixedSize(7)"] | typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[7, 1]"], upper_torque_threshold_acceleration: typing.SupportsFloat | typing.SupportsIndex | typing.Annotated[collections.abc.Sequence[typing.SupportsFloat | typing.SupportsIndex], "FixedSize(7)"] | typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[7, 1]"], lower_torque_threshold_nominal: typing.SupportsFloat | typing.SupportsIndex | typing.Annotated[collections.abc.Sequence[typing.SupportsFloat | typing.SupportsIndex], "FixedSize(7)"] | typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[7, 1]"], upper_torque_threshold_nominal: typing.SupportsFloat | typing.SupportsIndex | typing.Annotated[collections.abc.Sequence[typing.SupportsFloat | typing.SupportsIndex], "FixedSize(7)"] | typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[7, 1]"], lower_force_threshold_acceleration: typing.SupportsFloat | typing.SupportsIndex | typing.Annotated[collections.abc.Sequence[typing.SupportsFloat | typing.SupportsIndex], "FixedSize(6)"] | typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[6, 1]"], upper_force_threshold_acceleration: typing.SupportsFloat | typing.SupportsIndex | typing.Annotated[collections.abc.Sequence[typing.SupportsFloat | typing.SupportsIndex], "FixedSize(6)"] | typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[6, 1]"], lower_force_threshold_nominal: typing.SupportsFloat | typing.SupportsIndex | typing.Annotated[collections.abc.Sequence[typing.SupportsFloat | typing.SupportsIndex], "FixedSize(6)"] | typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[6, 1]"], upper_force_threshold_nominal: typing.SupportsFloat | typing.SupportsIndex | typing.Annotated[collections.abc.Sequence[typing.SupportsFloat | typing.SupportsIndex], "FixedSize(6)"] | typing.Annotated[numpy.typing.ArrayLike, numpy.float64, "[6, 1]"]) -> None:
        """
        Set the collision behavior of the robot.
        
        Args:
            lower_torque_threshold_acceleration: The lower torque threshold for the collision behavior in Nm
                                                 during acceleration.
            upper_torque_threshold_acceleration: The upper torque threshold for the collision behavior in Nm
                                                 during acceleration.
            lower_torque_threshold_nominal: The lower torque threshold for the collision behavior in Nm
                                            during nominal operation.
            upper_torque_threshold_nominal: The upper torque threshold for the collision behavior in Nm
                                            during nominal operation.
            lower_force_threshold_acceleration: The lower force threshold for the collision behavior in N
                                                during acceleration.
            upper_force_threshold_acceleration: The upper force threshold for the collision behavior in N
                                                during acceleration.
            lower_force_threshold_nominal: The lower force threshold for the collision behavior in N during
                                           nominal operation.
            upper_force_threshold_nominal: The upper force threshold for the collision behavior in N during
                                           nominal operation.
        """
    def set_ee(self, NE_T_EE: typing.Annotated[collections.abc.Sequence[typing.SupportsFloat | typing.SupportsIndex], "FixedSize(16)"]) -> None:
        """
        Sets the transformation :math:`^{NE}T_{EE}` from nominal end effector to end effector frame.
        
        The transformation matrix is represented as a vectorized 4x4 matrix in column-major format.
        
        Args:
            NE_T_EE: Vectorized NE-to-EE transformation matrix :math:`^{NE}T_{EE}`, column-major.
        
        Raises:
            CommandException: if the Control reports an error.
            NetworkException: if the connection is lost, e.g. after a timeout.
        
        See also:
            RobotState::NE_T_EE for end effector pose in ne-frame "nominal end effector frame NE".
        
        See also:
            RobotState::O_T_EE for end effector pose in o-frame "world base frame O".
        
        See also:
            RobotState::F_T_EE for end effector pose in f-frame "flange frame F".
        """
    def set_guiding_mode(self, guiding_mode: typing.Annotated[collections.abc.Sequence[bool], "FixedSize(6)"], elbow: bool) -> None:
        """
        Locks or unlocks guiding mode movement in (x, y, z, roll, pitch, yaw).
        
        If a flag is set to true, movement is unlocked.
        
        Args:
            guiding_mode: Unlocked movement in (x, y, z, R, P, Y) in guiding mode.
            elbow: True if the elbow is free in guiding mode, false otherwise.
        
        Raises:
            CommandException: if the Control reports an error.
            NetworkException: if the connection is lost, e.g. after a timeout.
        
        Note:
            Guiding mode can be enabled by pressing the two opposing buttons near the robot's flange.
        """
    def set_joint_impedance(self, K_theta: typing.Annotated[collections.abc.Sequence[typing.SupportsFloat | typing.SupportsIndex], "FixedSize(7)"]) -> None:
        """
        Sets the impedance for each joint in the internal controller.
        
        User-provided torques are not affected by this setting.
        
        Args:
            K_theta: Joint impedance values :math:`K_{\\theta_{1-7}} = \\in [0,14250] \\frac{Nm}{rad}`
        
        Raises:
            CommandException: if the Control reports an error.
            NetworkException: if the connection is lost, e.g. after a timeout.
        """
    def set_k(self, EE_T_K: typing.Annotated[collections.abc.Sequence[typing.SupportsFloat | typing.SupportsIndex], "FixedSize(16)"]) -> None:
        """
        Sets the transformation :math:`^{EE}T_K` from end effector frame to stiffness frame.
        
        The transformation matrix is represented as a vectorized 4x4 matrix in column-major format.
        
        Args:
            EE_T_K: Vectorized EE-to-K transformation matrix :math:`^{EE}T_K`, column-major.
        
        Raises:
            CommandException: if the Control reports an error.
            NetworkException: if the connection is lost, e.g. after a timeout.
        
        See also:
            Robot for an explanation of the stiffness frame.
        """
    def set_load(self, load_mass: typing.SupportsFloat | typing.SupportsIndex, F_x_Cload: typing.Annotated[collections.abc.Sequence[typing.SupportsFloat | typing.SupportsIndex], "FixedSize(3)"], load_inertia: typing.Annotated[collections.abc.Sequence[typing.SupportsFloat | typing.SupportsIndex], "FixedSize(9)"]) -> None:
        """
        Sets dynamic parameters of a payload.
        
        Args:
            load_mass: Mass of the load in :math:`[kg]`.
            F_x_Cload: Translation from flange to center of mass of load :math:`^Fx_{C_\\text{load}}` in
                            :math:`[m]`.
            load_inertia: Inertia matrix :math:`I_\\text{load}` in :math:`[kg \\times m^2]`, column-
                               major.
        
        Raises:
            CommandException: if the Control reports an error.
            NetworkException: if the connection is lost, e.g. after a timeout.
        
        Note:
            This is not for setting end effector parameters, which have to be set in the administrator's
            interface.
        """
    def stop(self) -> None:
        """
        Stops all currently running motions.
        
        If a control or motion generator loop is running in another thread, it will be preempted with a
        franka::ControlException.
        
        Raises:
            CommandException: if the Control reports an error.
            NetworkException: if the connection is lost, e.g. after a timeout.
        """
    @property
    def current_cartesian_state(self) -> CartesianState:
        """
        Returns the current cartesian state of the robot.
        
        Returns:
            The current cartesian state of the robot.
        """
    @property
    def current_cartesian_velocity(self) -> RobotVelocity:
        """
        Returns the current cartesian velocity of the robot.
        
        Returns:
            The current cartesian velocity of the robot.
        """
    @property
    def current_control_signal_type(self) -> ControlSignalType | None:
        """
        The type of the current control signal.
        """
    @property
    def current_joint_positions(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 1]"]:
        """
        Returns the current joint positions of the robot.
        
        Returns:
            The current joint positions of the robot.
        """
    @property
    def current_joint_state(self) -> JointState:
        """
        Returns the current joint state of the robot.
        
        Returns:
            The current joint state of the robot.
        """
    @property
    def current_joint_velocities(self) -> typing.Annotated[numpy.typing.NDArray[numpy.float64], "[7, 1]"]:
        """
        Returns the current joint velocities of the robot.
        
        Returns:
            The current joint velocities of the robot.
        """
    @property
    def current_pose(self) -> RobotPose:
        """
        Returns the current pose of the robot.
        
        Returns:
            The current pose of the robot.
        """
    @property
    def elbow_acceleration_limit(self) -> DoubleDynamicsLimit:
        """
        Elbow acceleration limit [rad/s²].
        """
    @property
    def elbow_jerk_limit(self) -> DoubleDynamicsLimit:
        """
        Elbow jerk limit [rad/s³].
        """
    @property
    def elbow_velocity_limit(self) -> DoubleDynamicsLimit:
        """
        Elbow velocity limit [rad/s].
        """
    @property
    def fci_hostname(self) -> str:
        """
        The hostname of the robot.
        """
    @property
    def has_errors(self) -> bool:
        """
        Returns whether the robot has errors.
        
        Returns:
            Whether the robot has errors.
        """
    @property
    def is_in_control(self) -> bool:
        """
        Whether the robot is currently in control, i.e. a motion is being executed.
        """
    @property
    def joint_acceleration_limit(self) -> VectorDynamicsLimit:
        """
        Joint acceleration limit [rad/s²].
        """
    @property
    def joint_jerk_limit(self) -> VectorDynamicsLimit:
        """
        Joint jerk limit [rad/s³].
        """
    @property
    def joint_velocity_limit(self) -> VectorDynamicsLimit:
        """
        Joint velocity limit [rad/s].
        """
    @property
    def model(self) -> Model:
        """
        The model of the robot.
        
        The model is loaded in the constructor, so calling this function does not incur any overhead.
        """
    @property
    def model_urdf(self) -> str:
        """
        The URDF of the robot model as string.
        """
    @property
    def relative_dynamics_factor(self) -> RelativeDynamicsFactor:
        """
        Returns the current global relative dynamics factor of the robot.
        
        Returns:
            The current relative dynamics factor of the robot.
        """
    @relative_dynamics_factor.setter
    def relative_dynamics_factor(self, arg1: RelativeDynamicsFactor | float) -> None:
        ...
    @property
    def rotation_acceleration_limit(self) -> DoubleDynamicsLimit:
        """
        Rotational acceleration limit [rad/s²].
        """
    @property
    def rotation_jerk_limit(self) -> DoubleDynamicsLimit:
        """
        Rotational jerk limit [rad/s³].
        """
    @property
    def rotation_velocity_limit(self) -> DoubleDynamicsLimit:
        """
        Rotational velocity limit [rad/s].
        """
    @property
    def state(self) -> RobotState:
        """
        Returns the current state of the robot.
        
        Returns:
            The current state of the robot.
        """
    @property
    def translation_acceleration_limit(self) -> DoubleDynamicsLimit:
        """
        Translational acceleration limit [m/s²].
        """
    @property
    def translation_jerk_limit(self) -> DoubleDynamicsLimit:
        """
        Translational jerk limit [m/s³].
        """
    @property
    def translation_velocity_limit(self) -> DoubleDynamicsLimit:
        """
        Translational velocity limit [m/s].
        """
ImpedanceMotion = CartesianImpedanceBase
